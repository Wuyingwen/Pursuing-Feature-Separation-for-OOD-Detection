# -*- coding: utf-8 -*-
# Triplet Loss：一对一
# InfoNCE Loss：一对多

import torch
import torch.nn as nn
import torch.nn.functional as F

class TripletLoss(nn.Module):
    def __init__(self, margin=1.0):
        super(TripletLoss, self).__init__()
        self.margin = margin

    def forward(self, anchor, positive, negative):
        distance_positive = (anchor - positive).pow(2).sum(1)  # Euclidean distance
        distance_negative = (anchor - negative).pow(2).sum(1)  # Euclidean distance
        losses = F.relu(distance_positive - distance_negative + self.margin)
        return losses.mean()

# Example usage
triplet_loss = TripletLoss(margin=1.0)
anchor = torch.randn(100, 128)  # 100 samples of 128-dimensional embeddings
positive = torch.randn(100, 128)
negative = torch.randn(100, 128)
loss = triplet_loss(anchor, positive, negative)
print("Triplet Loss:", loss)

