import scipy.io

def extract_wnids_from_meta(mat_file_path, output_file_path):
    # 加载 .mat 文件
    meta = scipy.io.loadmat(mat_file_path)
    
    # 提取 synsets，这是一个结构数组，其中包含了类别信息
    synsets = meta['synsets']
    
    # 提取 wnids 并存储到列表中
    wnids = [synset[0][1][0] for synset in synsets]
    
    # 将 wnids 写入到文本文件中
    with open(output_file_path, 'w') as file:
        for wnid in wnids:
            file.write(f"{wnid}\n")

if __name__ == "__main__":
    mat_file_path = '/home/hadoop-contentunderstanding/dolphinfs_hdd_hadoop-contentunderstanding/wuyingwen02/DAL/data/ILSVRC2012/ILSVRC2012_devkit_t12/data/meta.mat'  # 修改为你的 meta.mat 文件路径
    output_file_path = '/home/hadoop-contentunderstanding/dolphinfs_hdd_hadoop-contentunderstanding/wuyingwen02/DAL/data/ILSVRC2012/wnids.txt'  # 修改为你想要保存 wnids.txt 的路径
    
    extract_wnids_from_meta(mat_file_path, output_file_path)