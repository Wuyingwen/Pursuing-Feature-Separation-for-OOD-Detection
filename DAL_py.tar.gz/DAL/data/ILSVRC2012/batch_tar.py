# -*- coding: utf-8 -*-
import os
import subprocess

def batch_extract(source_dir, target_dir):
    # 确保目标目录存在
    if not os.path.exists(target_dir):
        os.makedirs(target_dir)

    # 遍历源目录中的所有文件
    for file in os.listdir(source_dir):
        if file.endswith(".tar") or file.endswith(".tar.gz"):
            # 构建完整的文件路径
            file_path = os.path.join(source_dir, file)
            target_dir_2 = os.path.join(target_dir, file[:-4])
            os.makedirs(target_dir_2, exist_ok=True)
            # print('target_dir:', target_dir)
            # print(fsdfds)
            # 构建解压命令
            command = f"tar -xvf {file_path} -C {target_dir_2}"
            # 执行解压命令
            subprocess.run(command, shell=True)
            print(f"Extracted {file} to {target_dir_2}")

# 使用示例
source_directory = './train'  # tar 文件所在的目录
target_directory = './train'  # 解压到的目标目录
batch_extract(source_directory, target_directory)
