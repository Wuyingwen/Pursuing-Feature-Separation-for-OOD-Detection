import scipy.io
import pandas as pd
import os
import shutil

def organize_imagenet_validation_set(meta_file_path, ground_truth_path, images_dir, output_dir):
    meta = scipy.io.loadmat(meta_file_path)
    synsets = meta['synsets']
    # for item in synsets:
    #     print(item[0][0][0], item[0][1][0], item[0][2][0])
    # print(fsdfds)
    synset_mapping = {int(item[0][0][0]): item[0][1][0] for item in synsets}
    # print(synset_mapping)

    ground_truth = pd.read_csv(ground_truth_path, header=None, names=['label_id'])

    if not os.path.exists(output_dir):
        os.makedirs(output_dir)
 
    for idx, row in ground_truth.iterrows():
        image_file = f'ILSVRC2012_val_{idx+1:08d}.JPEG'
        label_id = row['label_id']
        # print(label_id)
        label_name = synset_mapping[label_id]   ## label_name should be n0xxxx

        target_dir = os.path.join(output_dir, label_name)
        if not os.path.exists(target_dir):
            os.makedirs(target_dir)

        source_path = os.path.join(images_dir, image_file)
        target_path = os.path.join(target_dir, image_file)
        shutil.move(source_path, target_path)

if __name__ == "__main__":
    meta_file_path = '/home/hadoop-contentunderstanding/dolphinfs_hdd_hadoop-contentunderstanding/wuyingwen02/DAL/data/ILSVRC2012/ILSVRC2012_devkit_t12/data/meta.mat'
    ground_truth_path = '/home/hadoop-contentunderstanding/dolphinfs_hdd_hadoop-contentunderstanding/wuyingwen02/DAL/data/ILSVRC2012/ILSVRC2012_devkit_t12/data/ILSVRC2012_validation_ground_truth.txt'
    images_dir = '/home/hadoop-contentunderstanding/dolphinfs_hdd_hadoop-contentunderstanding/wuyingwen02/DAL/data/ILSVRC2012/val'
    output_dir = '/home/hadoop-contentunderstanding/dolphinfs_hdd_hadoop-contentunderstanding/wuyingwen02/DAL/data/ILSVRC2012/val'
    
    organize_imagenet_validation_set(meta_file_path, ground_truth_path, images_dir, output_dir)



