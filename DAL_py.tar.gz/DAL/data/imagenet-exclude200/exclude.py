import os
import shutil

def remove_tiny_imagenet_classes(imagenet_path, tiny_wnids_path):
    # 读取 Tiny ImageNet-200 的类别 ID
    with open(tiny_wnids_path, 'r') as f:
        tiny_wnids = [line.strip() for line in f]

    # 遍历 ImageNet 数据集的每个类别文件夹
    for wnid in os.listdir(imagenet_path):
        if wnid in tiny_wnids:
            # 如果类别在 Tiny ImageNet-200 中，删除整个文件夹
            class_folder = os.path.join(imagenet_path, wnid)
            shutil.rmtree(class_folder)
            print(f"Removed class folder: {class_folder}")

# 使用示例
imagenet_path = '/home/hadoop-contentunderstanding/dolphinfs_hdd_hadoop-contentunderstanding/wuyingwen02/DAL/data/imagenet-exclude200'  # 修改为你的 ImageNet 数据集路径
tiny_wnids_path = '/home/hadoop-contentunderstanding/dolphinfs_hdd_hadoop-contentunderstanding/wuyingwen02/DAL/data/tiny-imagenet-200/tiny-imagenet-200/wnids.txt'  # 修改为你的 Tiny ImageNet wnids.txt 文件路径
remove_tiny_imagenet_classes(imagenet_path, tiny_wnids_path)