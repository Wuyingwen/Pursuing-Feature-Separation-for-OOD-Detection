import os
import shutil
import random

def select_random_classes(source_dir, target_dir, num_classes=10):
    # 获取所有类别的目录
    all_classes = [d for d in os.listdir(source_dir) if os.path.isdir(os.path.join(source_dir, d))]
    
    # 随机选择 num_classes 个类别
    selected_classes = random.sample(all_classes, num_classes)
    
    # 确保目标目录存在
    if not os.path.exists(target_dir):
        os.makedirs(target_dir)
    
    # 复制选定类别的文件夹到目标目录
    for class_name in selected_classes:
        src_path = os.path.join(source_dir, class_name)
        dst_path = os.path.join(target_dir, class_name)
        shutil.copytree(src_path, dst_path)
        print(f"Copied {class_name} to {target_dir}")

# 使用示例
source_directory = '/path/to/imagenet/train'  # ImageNet 训练数据的路径
target_directory = '/path/to/small_imagenet/train'  # 目标路径，用于存储较小的数据集
select_random_classes(source_directory, target_directory)