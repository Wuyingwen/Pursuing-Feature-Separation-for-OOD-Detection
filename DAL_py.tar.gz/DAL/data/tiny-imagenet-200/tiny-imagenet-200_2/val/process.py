import os
import shutil

def organize_val_images(base_path):
    val_annotations_path = os.path.join(base_path, 'val', 'val_annotations.txt')
    val_images_path = os.path.join(base_path, 'val', 'images')  # 假设验证图像存储在这个目录下
    val_classes_path = os.path.join(base_path, 'val', 'classes')  # 创建类别目录的路径

    # 确保类别目录存在
    if not os.path.exists(val_classes_path):
        os.mkdir(val_classes_path)

    # 读取验证标签
    with open(val_annotations_path, 'r') as f:
        for line in f:
            parts = line.strip().split()
            image_file = parts[0]
            image_label_wnid = parts[1]

            # 为每个类别创建一个文件夹
            class_folder = os.path.join(val_classes_path, image_label_wnid)
            if not os.path.exists(class_folder):
                os.mkdir(class_folder)

            # 移动图像文件到相应的类别文件夹
            source_path = os.path.join(val_images_path, image_file)
            destination_path = os.path.join(class_folder, image_file)
            shutil.move(source_path, destination_path)

# 使用示例
base_path = '/home/hadoop-contentunderstanding/dolphinfs_hdd_hadoop-contentunderstanding/wuyingwen02/DAL/data/tiny-imagenet-200/tiny-imagenet-200'  # 修改为你的 Tiny ImageNet-200 路径
organize_val_images(base_path)