# -*- coding: utf-8 -*-

# CUDA_VISIBLE_DEVICES=2 python dissusion.py cifar10 --score_type knn --check _oe
# CUDA_VISIBLE_DEVICES=3 python dissusion.py cifar100 --score_type knn --check _oe

import numpy as np
import sys
import argparse
import torch
import torch.nn as nn
import torch.backends.cudnn as cudnn
import torchvision.transforms as trn
import torchvision.datasets as dset
import torch.nn.functional as F
from models.wrn import WideResNet

import utils.svhn_loader as svhn
from utils.display_results import get_measures, print_measures
from utils.tinyimages_80mn_loader import TinyImages
import torchvision
import faiss
import os

parser = argparse.ArgumentParser(description='DAL training procedure on the CIFAR benchmark',
                                 formatter_class=argparse.ArgumentDefaultsHelpFormatter)
parser.add_argument('dataset', type=str, choices=['cifar10', 'cifar100'],
                    help='Choose between CIFAR-10, CIFAR-100.')

# Optimization options
parser.add_argument('--epochs', '-e', type=int, default=50, help='Number of epochs to train.')
parser.add_argument('--learning_rate', '-lr', type=float, default=0.01, help='The initial learning rate.')
parser.add_argument('--batch_size', '-b', type=int, default=128, help='Batch size.')
parser.add_argument('--oe_batch_size', type=int, default=256, help='Batch size.')
parser.add_argument('--test_bs', type=int, default=200)
parser.add_argument('--momentum', type=float, default=0.9, help='Momentum.')
parser.add_argument('--decay', '-d', type=float, default=0.0005, help='Weight decay (L2 penalty).')
# WRN Architecture
parser.add_argument('--layers', default=40, type=int, help='total number of layers')
parser.add_argument('--widen-factor', default=2, type=int, help='widen factor')
parser.add_argument('--droprate', default=0.3, type=float, help='dropout probability')
# DAL hyper parameters
parser.add_argument('--gamma', default=1, type=float)
parser.add_argument('--beta',  default=0.5, type=float)
parser.add_argument('--rho',   default=0.01, type=float)
parser.add_argument('--strength', default=0.01, type=float)
parser.add_argument('--warmup', type=int, default=0)
parser.add_argument('--iter', default=10, type=int)
# Others
parser.add_argument('--out_as_pos', action='store_true', help='OE define OOD data as positive.')
parser.add_argument('--seed', type=int, default=1, help='seed for np(tinyimages80M sampling); 1|2|8|100|107')
# Energy-OE
parser.add_argument('--m_in', type=float, default=-25., help='default: -25. margin for in-distribution; above this value will be penalized')
parser.add_argument('--m_out', type=float, default=-7., help='default: -7. margin for out-distribution; below this value will be penalized')
parser.add_argument('--energy_beta', default=0.1, type=float, help='beta for energy fine tuning loss')
############
parser.add_argument('--check', type=str, default='_vanilla', help='_vanilla, _oe, _dal, _ours')
parser.add_argument('--score_type', type=str, default='msp', help='energy, knn')
parser.add_argument('--data_type', type=str, default='id', help='ood')


args = parser.parse_args()
torch.manual_seed(1)
np.random.seed(args.seed)
torch.cuda.manual_seed(1)

print(args.gamma, args.beta, args.rho)

cudnn.benchmark = True  # fire on all cylinders


# mean and standard deviation of channels of CIFAR-10 images
mean = [x / 255 for x in [125.3, 123.0, 113.9]]
std = [x / 255 for x in [63.0, 62.1, 66.7]]

train_transform = trn.Compose([trn.RandomHorizontalFlip(), trn.RandomCrop(32, padding=4),
                                trn.ToTensor(), trn.Normalize(mean, std)])
test_transform = trn.Compose([trn.ToTensor(), trn.Normalize(mean, std)])
# test_transform_imagenet = trn.Compose([trn.Resize((32,32)), trn.ToTensor(), trn.Normalize(mean, std)])
test_transform_imagenet = trn.Compose([trn.ToTensor(), trn.Normalize(mean, std)])

if args.dataset == 'cifar10':
    train_data_in = dset.CIFAR10('../data', train=True, transform=test_transform)
    test_data = dset.CIFAR10('../data', train=False, transform=test_transform)
    cifar_data = dset.CIFAR100('../data', train=False, transform=test_transform)
    # imagenet_data = torchvision.datasets.ImageFolder('/home/datasets/ILSVRC2012/val', test_transform_imagenet)

    # indices = [[] for _ in range(1000)]
    # # 遍历训练集
    # for i in range(len(imagenet_data)):
    #     img, label = imagenet_data[i]
    #     indices[label].append(i)
    # indices = np.array(indices)   
    # print('indices: ', indices.shape)

    # indices_i = indices[]
    # imagenet_data = torch.utils.data.Subset(imagenet_data, indices_i)

    num_classes = 10
else:
    train_data_in = dset.CIFAR100('../data', train=True, transform=test_transform)
    test_data = dset.CIFAR100('../data', train=False, transform=test_transform)
    cifar_data = dset.CIFAR10('../data', train=False, transform=test_transform)
    num_classes = 100

# ood_data = TinyImages(transform=trn.Compose([trn.ToTensor(), trn.ToPILImage(), trn.RandomCrop(32, padding=4), trn.RandomHorizontalFlip(), trn.ToTensor(), trn.Normalize(mean, std)]), exclude_cifar = True)
transform_for_ood = trn.Compose([trn.ToTensor(), trn.ToPILImage(), trn.RandomCrop(32, padding=4), trn.RandomHorizontalFlip(), trn.ToTensor(), trn.Normalize(mean, std)])
ood_x = np.load('../data/300K_random_images.npy')
class MyDataset(torch.utils.data.Dataset):
    def __init__(self, data, label, transform):
        # if trans == True:
        #     ##### 归一化 0-1 之间， data.shape:[bz,dim], e.g. [50000,128]
        #     normalizer = lambda x: (x-np.expand_dims(x.min(1), axis=1))/np.expand_dims(x.max(1)-x.min(1), axis=1)
        #     data = normalizer(data)

        self.data = data
        self.label = torch.from_numpy(label)
        self.transform = transform
    def __getitem__(self, index):
        data = self.data[index]
        label = self.label[index]

        data = self.transform(data)

        return data, label 

    def __len__(self):
        return self.data.shape[0]
ood_data = MyDataset(ood_x, np.zeros(ood_x.shape[0]), transform_for_ood)


train_loader_in = torch.utils.data.DataLoader(train_data_in, batch_size=args.batch_size, shuffle=True, num_workers=4, pin_memory=False)
train_loader_out = torch.utils.data.DataLoader(ood_data, batch_size=args.oe_batch_size, shuffle=True, num_workers=4, pin_memory=True)
test_loader = torch.utils.data.DataLoader(test_data, batch_size=args.batch_size, shuffle=True, num_workers=4, pin_memory=False)


texture_data = dset.ImageFolder(root="../data/ood_data/dtd/images", transform=trn.Compose([trn.Resize(32), trn.CenterCrop(32), trn.ToTensor(), trn.Normalize(mean, std)]))
svhn_data = svhn.SVHN(root='../data/ood_data/svhn/', split="test",transform=trn.Compose( [trn.ToTensor(), trn.Normalize(mean, std)]), download=False)
places365_data = dset.ImageFolder(root="../data/ood_data/places365", transform=trn.Compose([trn.Resize(32), trn.CenterCrop(32), trn.ToTensor(), trn.Normalize(mean, std)]))
lsunc_data = dset.ImageFolder(root="../data/ood_data/LSUN", transform=trn.Compose([trn.Resize(32), trn.ToTensor(), trn.Normalize(mean, std)]))

lsunfix_data = dset.ImageFolder(root="../data/ood_data/LSUN", transform=trn.Compose([trn.ToTensor(), trn.Normalize(mean, std)]))

isun_data = dset.ImageFolder(root="../data/ood_data/iSUN",transform=trn.Compose([trn.ToTensor(), trn.Normalize(mean, std)]))

texture_loader = torch.utils.data.DataLoader(texture_data, batch_size=args.test_bs, shuffle=True, num_workers=4, pin_memory=False)
svhn_loader = torch.utils.data.DataLoader(svhn_data, batch_size=args.test_bs, shuffle=True, num_workers=4, pin_memory=False)
places365_loader = torch.utils.data.DataLoader(places365_data, batch_size=args.test_bs, shuffle=True, num_workers=4, pin_memory=False)
lsunc_loader = torch.utils.data.DataLoader(lsunc_data, batch_size=args.test_bs, shuffle=True, num_workers=4, pin_memory=False)
lsunfix_loader = torch.utils.data.DataLoader(lsunfix_data, batch_size=args.test_bs, shuffle=True, num_workers=4, pin_memory=False)
isun_loader = torch.utils.data.DataLoader(isun_data, batch_size=args.test_bs, shuffle=True, num_workers=4, pin_memory=False)
cifar_loader = torch.utils.data.DataLoader(cifar_data, batch_size=args.test_bs, shuffle=True, num_workers=4, pin_memory=False)

# imagenet_data_fix = torchvision.datasets.ImageFolder('/data0/Dataset/Imagenet_fix', test_transform_imagenet)
# imagenet_loader_fix = torch.utils.data.DataLoader(imagenet_data_fix, batch_size=args.test_bs, shuffle=True, num_workers=4, pin_memory=False)

imagenet_data_resize = torchvision.datasets.ImageFolder('/data0/Dataset/Imagenet_resize', test_transform_imagenet)
imagenet_loader_resize = torch.utils.data.DataLoader(imagenet_data_resize, batch_size=args.test_bs, shuffle=True, num_workers=4, pin_memory=False)


ood_num_examples = len(test_data) // 5
expected_ap = ood_num_examples / (ood_num_examples + len(test_data))
concat = lambda x: np.concatenate(x, axis=0)
to_np = lambda x: x.data.cpu().numpy()

def knn(feat_log, feat_log_val, K=5):
    normalizer = lambda x: x / (np.linalg.norm(x, ord=2, axis=-1, keepdims=True) + 1e-10)
    # normalizer = lambda x: (x-np.expand_dims(x.min(1), axis=1))/np.expand_dims(x.max(1)-x.min(1), axis=1)
    prepos_feat = lambda x: np.ascontiguousarray(normalizer(x))# Last Layer only

    ftrain = prepos_feat(feat_log)
    ftest = prepos_feat(feat_log_val)

    #################### KNN score OOD detection #################
    index = faiss.IndexFlatL2(ftrain.shape[1])
    index.add(ftrain)
   
    D, _ = index.search(ftest, K)
    scores_in = -D[:,-1]
    
    return scores_in

def obtain_feature_loader(model, dataloader, save_path, save_name, args, check):
    if not os.path.exists(save_path + save_name + '_foward_feature'+check+'.npy'):
        forward_feature = []
        label = []
        total = 0
        for i, batch in enumerate(dataloader):
            if total > 50000:
                break
            
            inputs, targets = batch   
            inputs = inputs.cuda()
            targets = targets.cuda()

            total = total + targets.shape[0]
            
            output, feature = model.pred_emb(inputs)
            # output = model(inputs)
            forward_feature.append(feature.detach().cpu())
            label.append(targets.detach().cpu())

        forward_feature = torch.cat(forward_feature, 0)
        label = torch.cat(label, dim=0)
        forward_feature = forward_feature.numpy()
        label = label.numpy()
        # print(forward_feature.shape, label.shape)
        np.save(save_path + save_name + '_foward_feature'+check+'.npy', forward_feature)
        np.save(save_path + save_name + '_label'+check+'.npy', label)
    else:
        forward_feature = np.load(save_path + save_name + '_foward_feature'+check+'.npy')
        label = np.load(save_path + save_name + '_label'+check+'.npy')
        # print(forward_feature.shape, label.shape)
    # dataset = MyDataset(forward_feature, label)
    # feature_dataloader = torch.utils.data.DataLoader(dataset, batch_size=args.batch_size, shuffle=False, num_workers=args.threads)

    return forward_feature # , label, feature_dataloader

def get_ood_scores(loader, score_type='msp', in_dist=False):
    _score = []
    net.eval()

    file_name=os.path.basename(__file__).split(".")[0]
    save_path = file_name + '/'
    os.makedirs(save_path, exist_ok=True)
    save_name  = args.dataset
    train_forward_feature = obtain_feature_loader(net, train_loader_in, save_path, save_name, args, args.check)

    with torch.no_grad():
        for batch_idx, (data, target) in enumerate(loader):
            if batch_idx >= ood_num_examples // args.test_bs and in_dist is False:
                break
            data, target = data.cuda(), target.cuda()
            output, emb = net.pred_emb(data)
            if score_type == 'msp':
                smax = to_np(F.softmax(output, dim=1))
                _score.append(-np.max(smax, axis=1))
            elif score_type == 'energy':
                temper = 1
                conf = temper * (torch.logsumexp(output / temper, dim=1))
                _score.append(-conf.data.cpu().numpy())
            elif score_type == 'knn':
                emb = emb.cpu().detach().numpy()
                conf = knn(train_forward_feature, emb, K=5)
                _score.append(-conf)
            elif score_type == 'dim':
                target = torch.argmax(output.data, 1).detach()
                emb = emb/torch.norm(emb, dim=1, keepdim=True)
                a = net.fc.weight.data/torch.norm(net.fc.weight.data, dim=1, keepdim=True)
                conf = torch.norm((emb @ a.T), p=1, dim=1)
                _score.append(-conf.cpu().detach().numpy())
                # confs = []
                # for k in range(data.shape[0]):
                #     confs.append(-(emb[k] @ a[target[k]].unsqueeze(1)).squeeze().item())
                # _score.append(confs)
            elif score_type == 'ensemble':
                target = torch.argmax(output.data, 1).detach()
                emb = emb/torch.norm(emb, dim=1, keepdim=True)
                a = net.fc.weight.data/torch.norm(net.fc.weight.data, dim=1, keepdim=True)
                conf1 = torch.norm((emb @ a.T), p=1, dim=1)

                smax = to_np(F.softmax(output, dim=1))
                conf2 = -np.max(smax, axis=1)
                _score.append(-conf1.cpu().detach().numpy()+conf2)
    if in_dist:
        return concat(_score).copy() # , concat(_right_score).copy(), concat(_wrong_score).copy()
    else:
        return concat(_score)[:ood_num_examples].copy()

def get_and_print_results(ood_loader, in_score, score_type='msp', num_to_avg=1):
    net.eval()
    aurocs, auprs, fprs = [], [], []
    for _ in range(num_to_avg):
        out_score = get_ood_scores(ood_loader, score_type)
        print(out_score.shape)
        if args.out_as_pos: # OE's defines out samples as positive
            measures = get_measures(out_score, in_score)
        else:
            measures = get_measures(-in_score, -out_score)
        aurocs.append(measures[0]); auprs.append(measures[1]); fprs.append(measures[2])
    auroc = np.mean(aurocs); aupr = np.mean(auprs); fpr = np.mean(fprs)
    print_measures(auroc, aupr, fpr, '')
    return fpr, auroc, aupr

def train(epoch, gamma):

    net.train()

    loss_avg = 0.0
    train_loader_out.dataset.offset = np.random.randint(len(train_loader_in.dataset))
    for batch_idx, (in_set, out_set) in enumerate(zip(train_loader_in, train_loader_out)):

        data, target = torch.cat((in_set[0], out_set[0]), 0), in_set[1]
        data, target = data.cuda(), target.cuda()

        x, emb = net.pred_emb(data)
        l_ce = F.cross_entropy(x[:len(in_set[0])], target)
        l_oe_old = - (x[len(in_set[0]):].mean(1) - torch.logsumexp(x[len(in_set[0]):], dim=1)).mean()

        # smax_oe = F.log_softmax(x[len(in_set[0]):] - torch.max(x[len(in_set[0]):], dim=1, keepdim=True)[0], dim=1)
        # oe_loss = -1 * smax_oe.mean()  # minimizing cross entropy
        # print(l_oe_old, oe_loss)
        # print(fdsfs)

        emb_oe = emb[len(in_set[0]):].detach()
        emb_bias = torch.rand_like(emb_oe) * 0.0001

        for _ in range(args.iter):
            emb_bias.requires_grad_()

            x_aug = net.fc(emb_bias + emb_oe)
            l_sur = - (x_aug.mean(1) - torch.logsumexp(x_aug, dim=1)).mean()
            r_sur = (emb_bias.abs()).mean(-1).mean()
            l_sur = l_sur - r_sur * gamma
            grads = torch.autograd.grad(l_sur, [emb_bias])[0]
            grads /= (grads ** 2).sum(-1).sqrt().unsqueeze(1)
            
            emb_bias = emb_bias.detach() + args.strength * grads.detach() # + torch.randn_like(grads.detach()) * 0.000001
            optimizer.zero_grad()
        
        gamma -= args.beta * (args.rho - r_sur.detach())
        gamma = gamma.clamp(min=0.0, max=args.gamma)
        if epoch >= args.warmup:
            x_oe = net.fc(emb[len(in_set[0]):] + emb_bias)
        else:    
            x_oe = net.fc(emb[len(in_set[0]):])
        
        l_oe = - (x_oe.mean(1) - torch.logsumexp(x_oe, dim=1)).mean()
        loss = l_ce + .5 * l_oe
        # loss = l_ce + l_oe

        # loss = l_ce + .5 * l_oe_old
        # loss = l_ce + l_oe_old
        # loss = l_ce
    
        optimizer.zero_grad()
        loss.backward()
        optimizer.step()

        loss_avg = loss_avg * 0.8 + float(loss) * 0.2
        sys.stdout.write('\r epoch %2d %d/%d loss %.2f' %(epoch, batch_idx + 1, len(train_loader_in), loss_avg))
        scheduler.step()
    return gamma

def train_energy_oe(epoch, gamma, args):

    net.train()

    loss_avg = 0.0
    train_loader_out.dataset.offset = np.random.randint(len(train_loader_in.dataset))
    for batch_idx, (in_set, out_set) in enumerate(zip(train_loader_in, train_loader_out)):

        data, target = torch.cat((in_set[0], out_set[0]), 0), in_set[1]
        data, target = data.cuda(), target.cuda()

        x, emb = net.pred_emb(data)
        l_ce = F.cross_entropy(x[:len(in_set[0])], target)

        in_len = len(in_set[0])
        cat_output = x

        E = -torch.logsumexp(cat_output, dim=1)
        Ec_in = E[:in_len]
        Ec_out = E[in_len:]
        in_energy_loss = torch.pow(F.relu(Ec_in-args.m_in), 2).mean()
        out_energy_loss = torch.pow(F.relu(args.m_out-Ec_out), 2).mean()
        
        loss = l_ce + args.energy_beta * (out_energy_loss + in_energy_loss)
    
        optimizer.zero_grad()
        loss.backward()
        optimizer.step()

        loss_avg = loss_avg * 0.8 + float(loss) * 0.2
        sys.stdout.write('\r epoch %2d %d/%d loss %.2f' %(epoch, batch_idx + 1, len(train_loader_in), loss_avg))
        scheduler.step()
    return gamma


def test_loss():
    net.eval()
    loss_avg = 0.0
    train_loader_out.dataset.offset = np.random.randint(len(train_loader_in.dataset))

    for batch_idx, (in_set, out_set) in enumerate(zip(train_loader_in, train_loader_out)):
        data, target = torch.cat((in_set[0], out_set[0]), 0), in_set[1]
        data, target = data.cuda(), target.cuda()

        x = net(data)
        l_ce = F.cross_entropy(x[:len(in_set[0])], target)
        l_oe_old = - (x[len(in_set[0]):].mean(1) - torch.logsumexp(x[len(in_set[0]):], dim=1)).mean()
        loss = l_ce + .5 * l_oe_old
        
        loss_avg = loss_avg * 0.8 + float(loss) * 0.2
        sys.stdout.write('\r %d/%d loss %.2f' %(batch_idx + 1, len(train_loader_in), loss_avg))

    return

def test():
    net.eval()
    correct = 0
    y, c = [], []
    with torch.no_grad():
        for data, target in test_loader:
            data, target = data.cuda(), target.cuda()
            output = net(data)
            pred = output.data.max(1)[1]
            correct += pred.eq(target.data).sum().item()
    return correct / len(test_loader.dataset) * 100


net = WideResNet(args.layers, num_classes, args.widen_factor, dropRate=args.droprate).cuda()

if args.check == '_vanilla':
    net.load_state_dict(torch.load('./models/'+ args.dataset + '_baseline_vanilla.pt')) # vanilla
elif args.check == '_oe':
    net.load_state_dict(torch.load('./models/'+ args.dataset + '_baseline_oe_v21.pt')) # OE
elif args.check == '_dal':
    net.load_state_dict(torch.load('./models/'+ args.dataset + '_baseline_aug_v22.pt')) # DAL
elif args.check == '_ours':
    # net.load_state_dict(torch.load('./models/'+ args.dataset + '_bz' + str(args.oe_batch_size) + '_feature_po_2_v11_21.pt')) # Ours
    net.load_state_dict(torch.load('./models/'+ args.dataset + '_bz' + str(args.oe_batch_size) + '_feature_po_2_v11_24.pt')) # Ours
net.eval()

##################################################################
# # CUDA_VISIBLE_DEVICES=2 python dissusion.py cifar10 --score_type knn --check _oe
# # CUDA_VISIBLE_DEVICES=3 python dissusion.py cifar100 --score_type knn --check _oe 
in_score = get_ood_scores(test_loader, score_type=args.score_type, in_dist=True)
metric_ll = []
metric_ll.append(get_and_print_results(svhn_loader, in_score, score_type=args.score_type))
metric_ll.append(get_and_print_results(lsunc_loader, in_score, score_type=args.score_type))
metric_ll.append(get_and_print_results(isun_loader, in_score, score_type=args.score_type))
metric_ll.append(get_and_print_results(texture_loader, in_score, score_type=args.score_type))
metric_ll.append(get_and_print_results(places365_loader, in_score, score_type=args.score_type))
# metric_ll.append(get_and_print_results(lsunfix_loader, in_score, score_type=args.score_type))
# metric_ll.append(get_and_print_results(imagenet_loader_resize, in_score, score_type=args.score_type))
# metric_ll.append(get_and_print_results(cifar_loader, in_score, score_type=args.score_type))

print('\n & %.2f & %.2f & %.2f' % tuple((100 * torch.Tensor(metric_ll).mean(0)).tolist()))
print('\n acc:', test())
print(fsdfs)
##################################################################
# Feature Separation Measurement
def qr_alter(omiga):
    for i in range(omiga.shape[0]):
        omiga[i] = omiga[i] - torch.sum(torch.mm(omiga[i].unsqueeze(0), omiga[0:i].T).T*omiga[0:i], dim=0)
        omiga[i] = omiga[i]/torch.norm(omiga[i])
    # print(omiga, omiga.shape)
    return omiga

def reconstruction_error(feature, net):
    a = net.fc.weight.data
    a = qr_alter(a)
    reconstruct_feature = feature @ a.T @ a
    error = feature - reconstruct_feature
    res  = torch.norm(error)/torch.norm(feature)
    return res

def euclidean_distance(feature, output, net):
    target = torch.argmax(output.data).detach()
    a = net.fc.weight.data[target]
    distance = feature - a
    res = torch.norm(distance)#/torch.norm(feature)
    return res

def cosine_similarity(feature, output, net):
    target = torch.argmax(output.data).detach()
    a = net.fc.weight.data[target]
    cosine = torch.sum(a*feature) / (torch.norm(feature) * torch.norm(a))
    return cosine

file_name=os.path.basename(__file__).split(".")[0]
save_path = file_name + '/'
os.makedirs(save_path, exist_ok=True)
# save_name  = args.dataset + '_train'
# train_forward_feature = obtain_feature_loader(net, train_loader_in, save_path, save_name, args, args.check)

save_name  = args.dataset + '_test'
test_forward_feature = obtain_feature_loader(net, test_loader, save_path, save_name, args, args.check)

save_name  = args.dataset + '_ood'
ood_forward_feature = obtain_feature_loader(net, lsunc_loader, save_path, save_name, args, args.check)

if args.data_type == 'id':
    forward_feature = test_forward_feature
else:
    forward_feature = ood_forward_feature

avg = []
for i in range(1000):
    feature = torch.from_numpy(forward_feature[i]).cuda()
    output = net.fc(feature)
    # print(feature.shape, output.shape)
    # res = euclidean_distance(feature, output, net)
    # res = cosine_similarity(feature, output, net)
    res = reconstruction_error(feature, net)
    avg.append(res)
avg = torch.Tensor(avg)
print('avg: ', avg.shape)
avg = torch.mean(avg)
print(args.data_type, avg)
    
# python dissusion.py cifar10 --data_type id --check _oe