import numpy as np
from mahalanobis_lib import get_Mahalanobis_score,sample_estimator,merge_and_generate_labels,block_split,load_characteristics


def extract_sample_class_mean_variance(model, train_loader, num_classes, data='cifar10'):
    if data == 'cifar10' or data == 'cifar100':
        extract_module = ['avg_pool']
    
    sample_class_mean, variance = sample_estimator(model, num_classes, train_loader, extract_module)
    print('mean:', sample_class_mean[0].shape, 'var:', variance[0].shape)
    # np.save('./maha/'+data+'_sample_class_mean.npy', sample_class_mean.cpu().numpy())
    # np.save('./maha/'+data+'_variance.npy', variance.cpu().numpy())
    return sample_class_mean, variance


def mahalanobis_official(model, test_loader, sample_class_mean, variance, num_classes, magnitude=0.01, data='cifar10', in_dist=False, ood_num_examples=0, test_bs=1):
    if data == 'cifar10' or data == 'cifar100':
        extract_module = ['avg_pool']

    Mahalanobis_test = []
    for batch_idx, batch in enumerate(test_loader):
        if batch_idx >= ood_num_examples // test_bs and in_dist is False:
            break
        inputs, targets = batch
        inputs = inputs.cuda()
        targets = targets.cuda()
        Mahalanobis_scores = get_Mahalanobis_score(inputs, model, num_classes, sample_class_mean, variance, magnitude, extract_module)
        Mahalanobis_test.extend(Mahalanobis_scores)

    Mahalanobis_test = np.asarray(Mahalanobis_test, dtype=np.float32)
    # print('Mahalanobis:', Mahalanobis_test.shape)

    scores = Mahalanobis_test.flatten()
    # print('scores:', scores.shape)

    return scores
