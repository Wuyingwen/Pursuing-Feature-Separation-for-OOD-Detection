# -*- coding: utf-8 -*-
### 查看 OOD feature 与 ID feature 的不同之处，能否约束扩大不同之处。
### 不同OOD样本的featrue的类似之处，比如约束特征上的对抗噪声在低维子空间内
### 验证select data算法，比如POEM的有效性（查看github代码）。直接在特征空间选择OOD data，而不在输出空间。
# CUDA_VISIBLE_DEVICES=2 python main_sam_imagenet.py imagenet --learning_rate=0.01 --epochs 20
# CUDA_VISIBLE_DEVICES=2 screen python main_sam_imagenet.py imagenet --learning_rate=0.07 --gamma=10 --beta=.01  --rho=10  --iter=10  --strength=1

import numpy as np
import sys
import argparse
import torch
import torch.nn as nn
import torch.backends.cudnn as cudnn
import torchvision.transforms as trn
import torchvision.datasets as dset
import torch.nn.functional as F
from models.wrn import WideResNet
import os
import faiss

import utils.svhn_loader as svhn
from utils.display_results import get_measures, print_measures
from utils.tinyimages_80mn_loader import TinyImages
import sys; sys.path.append("../..")
from sam import SAM
sys.path.append("..")
from utility.bypass_bn import enable_running_stats, disable_running_stats
from visualize_utils import get_feas_by_hook


parser = argparse.ArgumentParser(description='DAL training procedure on the CIFAR benchmark',
                                 formatter_class=argparse.ArgumentDefaultsHelpFormatter)
parser.add_argument('dataset', type=str, choices=['cifar10', 'cifar100','imagenet'],
                    help='Choose between CIFAR-10, CIFAR-100.')

parser.add_argument("--adaptive", default=True, type=bool, help="True if you want to use the Adaptive SAM.")
parser.add_argument("--sam_rho", default=2.0, type=float, help="Rho parameter for SAM.")
parser.add_argument("--sam_type", default='lce', type=str, help="")
# Optimization options
parser.add_argument('--epochs', '-e', type=int, default=50, help='Number of epochs to train.')
parser.add_argument('--learning_rate', '-lr', type=float, default=0.01, help='The initial learning rate.')
parser.add_argument('--batch_size', '-b', type=int, default=64, help='Batch size.')
parser.add_argument('--oe_batch_size', type=int, default=64, help='Batch size.')
parser.add_argument('--test_bs', type=int, default=200)
parser.add_argument('--momentum', type=float, default=0.9, help='Momentum.')
parser.add_argument('--decay', '-d', type=float, default=0.0005, help='Weight decay (L2 penalty).')
# WRN Architecture
parser.add_argument('--layers', default=40, type=int, help='total number of layers')
parser.add_argument('--widen-factor', default=2, type=int, help='widen factor')
parser.add_argument('--droprate', default=0.3, type=float, help='dropout probability')
# DAL hyper parameters
parser.add_argument('--gamma', default=1, type=float)
parser.add_argument('--beta',  default=0.5, type=float)
parser.add_argument('--rho',   default=0.01, type=float)
parser.add_argument('--strength', default=0.01, type=float)
parser.add_argument('--warmup', type=int, default=0)
parser.add_argument('--iter', default=10, type=int)
# Others
parser.add_argument('--out_as_pos', action='store_true', help='OE define OOD data as positive.')
parser.add_argument('--seed', type=int, default=1, help='seed for np(tinyimages80M sampling); 1|2|8|100|107')


args = parser.parse_args()
torch.manual_seed(1)
np.random.seed(args.seed)
torch.cuda.manual_seed(1)

print(args.gamma, args.beta, args.rho)

cudnn.benchmark = True  # fire on all cylinders

class Logger(object):
    def __init__(self, logFile="Default.log"):
        self.terminal = sys.stdout
        self.log = open(logFile, 'a')

    def write(self, message):
        self.terminal.write(message)
        self.log.write(message)

    def flush(self):
        pass
sys.stdout = Logger('record/output.log')



##################### imagenet auxiliary OOD data #################################
# mean and standard deviation of channels of CIFAR-10 images
if args.dataset == 'cifar10' or args.dataset == 'cifar100':
    mean = [x / 255 for x in [125.3, 123.0, 113.9]]
    std = [x / 255 for x in [63.0, 62.1, 66.7]]

    train_transform = trn.Compose([trn.RandomHorizontalFlip(), trn.RandomCrop(32, padding=4),
                                    trn.ToTensor(), trn.Normalize(mean, std)])
    test_transform = trn.Compose([trn.ToTensor(), trn.Normalize(mean, std)])
elif args.dataset == 'imagenet':
    train_transform = trn.Compose([
            trn.Resize(256),
            trn.CenterCrop(224),
            trn.RandomHorizontalFlip(),
            trn.ToTensor(),
            trn.Normalize(mean=[0.485, 0.456, 0.406],
                                std=[0.229, 0.224, 0.225]),
        ])
    test_transform = trn.Compose([
            trn.Resize(256),
            trn.CenterCrop(224),
            trn.ToTensor(),
            trn.Normalize(mean=[0.485, 0.456, 0.406],
                                std=[0.229, 0.224, 0.225]),
        ])

if args.dataset == 'cifar10':
    train_data_in = dset.CIFAR10('../data', train=True, transform=train_transform)
    test_data = dset.CIFAR10('../data', train=False, transform=test_transform)
    cifar_data = dset.CIFAR100('../data', train=False, transform=test_transform) 
    num_classes = 10
elif args.dataset == 'cifar100':
    train_data_in = dset.CIFAR100('../data', train=True, transform=train_transform)
    test_data = dset.CIFAR100('../data', train=False, transform=test_transform)
    cifar_data = dset.CIFAR10('../data', train=False, transform=test_transform)
    num_classes = 100
elif args.dataset == 'imagenet':
    train_data_in = dset.ImageFolder('/home/datasets/ILSVRC2012/train', transform=train_transform)
    test_data = dset.ImageFolder('/home/datasets/ILSVRC2012/val', transform=test_transform)
    num_classes = 1000


if args.dataset == 'cifar10' or args.dataset == 'cifar100':
    # ood_data = TinyImages(transform=trn.Compose([trn.ToTensor(), trn.ToPILImage(), trn.RandomCrop(32, padding=4), trn.RandomHorizontalFlip(), trn.ToTensor(), trn.Normalize(mean, std)]), exclude_cifar = True)
    transform_for_ood = trn.Compose([trn.ToTensor(), trn.ToPILImage(), trn.RandomCrop(32, padding=4), trn.RandomHorizontalFlip(), trn.ToTensor(), trn.Normalize(mean, std)])
    ood_x = np.load('../data/300K_random_images.npy')
    class MyDataset(torch.utils.data.Dataset):
        def __init__(self, data, label, transform=None):
            self.data = data
            self.label = torch.from_numpy(label)
            self.transform = transform
        def __getitem__(self, index):
            data = self.data[index]
            label = self.label[index]

            if self.transform!=None:
                data = self.transform(data)

            return data, label 

        def __len__(self):
            return self.data.shape[0]
    ood_data = MyDataset(ood_x, np.zeros(ood_x.shape[0]), transform_for_ood)
elif args.dataset == 'imagenet':
    ood_data = dset.ImageFolder('/data0/Dataset/imagenet21k_resized/imagenet21k_val', transform=train_transform)


train_loader_in = torch.utils.data.DataLoader(train_data_in, batch_size=args.batch_size, shuffle=True, num_workers=4, pin_memory=False)
train_loader_out = torch.utils.data.DataLoader(ood_data, batch_size=args.oe_batch_size, shuffle=True, num_workers=4, pin_memory=True)
test_loader = torch.utils.data.DataLoader(test_data, batch_size=args.batch_size, shuffle=False, num_workers=4, pin_memory=False)


inat_data = dset.ImageFolder(root="../data/ood_data/imagenet/iNaturalist", transform=test_transform)
sun50_data = dset.ImageFolder(root="../data/ood_data/imagenet/SUN", transform=test_transform)
places50_data = dset.ImageFolder(root="../data/ood_data/imagenet/Places", transform=test_transform)
dtd_data = dset.ImageFolder(root="../data/ood_data/dtd/images", transform=test_transform)

inat_loader = torch.utils.data.DataLoader(inat_data, batch_size=args.test_bs, shuffle=True, num_workers=4, pin_memory=False)
sun50_loader = torch.utils.data.DataLoader(sun50_data, batch_size=args.test_bs, shuffle=True, num_workers=4, pin_memory=False)
places50_loader = torch.utils.data.DataLoader(places50_data, batch_size=args.test_bs, shuffle=True, num_workers=4, pin_memory=False)
dtd_loader = torch.utils.data.DataLoader(dtd_data, batch_size=args.test_bs, shuffle=True, num_workers=4, pin_memory=False)

ood_num_examples = len(test_data) // 5
expected_ap = ood_num_examples / (ood_num_examples + len(test_data))
concat = lambda x: np.concatenate(x, axis=0)
to_np = lambda x: x.data.cpu().numpy()
###################################################################################

def get_ood_scores(loader, in_dist=False):
    _score = []
    net.eval()
    with torch.no_grad():
        for batch_idx, (data, target) in enumerate(loader):
            if batch_idx >= ood_num_examples // args.test_bs and in_dist is False:
                break
            data, target = data.cuda(), target.cuda()
            #####################################################
            output = net(data)
            smax = to_np(F.softmax(output, dim=1))  # msp方法
            msp_confs = -np.max(smax, axis=1)
            _score.append(msp_confs)
            #####################################################
            # output, emb = net.pred_emb(data)
            # target = torch.argmax(output.data, 1).detach()
            # emb = emb/torch.norm(emb, dim=1, keepdim=True)
            # a = net.fc.weight.data/torch.norm(net.fc.weight.data, dim=1, keepdim=True)
            # confs = []
            # for k in range(data.shape[0]):
            #     confs.append(-(emb[k] @ a[target[k]].unsqueeze(1)).squeeze().item())
            # _score.append(confs)
            ################################################################            
    if in_dist:
        return concat(_score).copy() # , concat(_right_score).copy(), concat(_wrong_score).copy()
    else:
        return concat(_score)[:ood_num_examples].copy()

def get_and_print_results(ood_loader, in_score, num_to_avg=1):
    net.eval()
    aurocs, auprs, fprs = [], [], []
    for _ in range(num_to_avg):
        out_score = get_ood_scores(ood_loader)
        print(out_score.shape)
        if args.out_as_pos: # OE's defines out samples as positive
            measures = get_measures(out_score, in_score)
        else:
            measures = get_measures(-in_score, -out_score)
        aurocs.append(measures[0]); auprs.append(measures[1]); fprs.append(measures[2])
    auroc = np.mean(aurocs); aupr = np.mean(auprs); fpr = np.mean(fprs)
    print_measures(auroc, aupr, fpr, '')
    return fpr, auroc, aupr

def train(epoch, gamma):

    net.train()

    loss_avg = 0.0
    train_loader_out.dataset.offset = np.random.randint(len(train_loader_in.dataset))
    for batch_idx, (in_set, out_set) in enumerate(zip(train_loader_in, train_loader_out)):

        data, target = torch.cat((in_set[0], out_set[0]), 0), in_set[1]
        data, target = data.cuda(), target.cuda()

        x, emb = net.pred_emb(data)
        l_ce = F.cross_entropy(x[:len(in_set[0])], target)
        l_oe_old = - (x[len(in_set[0]):].mean(1) - torch.logsumexp(x[len(in_set[0]):], dim=1)).mean()

        emb_oe = emb[len(in_set[0]):].detach()
        emb_bias = torch.rand_like(emb_oe) * 0.0001

        for _ in range(args.iter):
            emb_bias.requires_grad_()

            x_aug = net.fc(emb_bias + emb_oe)
            l_sur = - (x_aug.mean(1) - torch.logsumexp(x_aug, dim=1)).mean()
            r_sur = (emb_bias.abs()).mean(-1).mean()
            l_sur = l_sur - r_sur * gamma
            grads = torch.autograd.grad(l_sur, [emb_bias])[0]
            grads /= (grads ** 2).sum(-1).sqrt().unsqueeze(1)
            
            emb_bias = emb_bias.detach() + args.strength * grads.detach() # + torch.randn_like(grads.detach()) * 0.000001
            optimizer.zero_grad()
        
        gamma -= args.beta * (args.rho - r_sur.detach())
        gamma = gamma.clamp(min=0.0, max=args.gamma)
        if epoch >= args.warmup:
            x_oe = net.fc(emb[len(in_set[0]):] + emb_bias)
        else:    
            x_oe = net.fc(emb[len(in_set[0]):])
        
        l_oe = - (x_oe.mean(1) - torch.logsumexp(x_oe, dim=1)).mean()
        loss = l_ce + .5 * l_oe
    
        optimizer.zero_grad()
        loss.backward()
        optimizer.step()

        loss_avg = loss_avg * 0.8 + float(loss) * 0.2
        sys.stdout.write('\r epoch %2d %d/%d loss %.2f' %(epoch, batch_idx + 1, len(train_loader_in), loss_avg))
        scheduler.step()
    return gamma

def test():
    net.eval()
    correct = 0
    y, c = [], []
    with torch.no_grad():
        for data, target in test_loader:
            data, target = data.cuda(), target.cuda()
            output = net(data)
            pred = output.data.max(1)[1]
            correct += pred.eq(target.data).sum().item()
    return correct / len(test_loader.dataset) * 100

def train_sam(epoch, gamma, type):
    net.train()
    loss_avg = 0.0
    train_loader_out.dataset.offset = np.random.randint(len(train_loader_in.dataset))

    for batch_idx, (in_set, out_set) in enumerate(zip(train_loader_in, train_loader_out)):
        data, target = torch.cat((in_set[0], out_set[0]), 0), in_set[1]
        data, target = data.cuda(), target.cuda()

        enable_running_stats(net)
        x = net(data)
        l_ce = F.cross_entropy(x[:len(in_set[0])], target)
        l_oe_old = - (x[len(in_set[0]):].mean(1) - torch.logsumexp(x[len(in_set[0]):], dim=1)).mean()
        if type == 'lce':
            loss = l_ce
        elif type == 'loe':
            loss = l_oe_old
        elif type == 'lce+loe':
            loss = l_ce + .5 * l_oe_old
        loss.backward()
        optimizer.first_step(zero_grad=True)

        disable_running_stats(net)
        x = net(data)
        l_ce = F.cross_entropy(x[:len(in_set[0])], target)
        l_oe_old = - (x[len(in_set[0]):].mean(1) - torch.logsumexp(x[len(in_set[0]):], dim=1)).mean()
        loss = l_ce + .5 * l_oe_old
        loss.backward()
        optimizer.second_step(zero_grad=True)

        loss_avg = loss_avg * 0.8 + float(loss) * 0.2
        sys.stdout.write('\r epoch %2d %d/%d loss %.2f' %(epoch, batch_idx + 1, len(train_loader_in), loss_avg))
        scheduler.step()

    return gamma

def obtain_feature_loader(net, dataloader, save_path, save_name, args, check):
    # for name,p in net.named_parameters():
    #     print(name, p.shape)
    # for n, m in net.named_modules():
    #     print(n)
    # print(fdsfsd)
    # if not os.path.exists(save_path + save_name + '_foward_feature'+check+'.npy'):
    if True:
        forward_feature = []
        label = []
        total = 0
        for i, batch in enumerate(dataloader):
            inputs, targets = batch   
            inputs = inputs.cuda()
            targets = targets.cuda()

            total = total + targets.shape[0]
            # 定义提取中间层的 Hook
            if args.dataset == 'cifar10' or args.dataset == 'cifar100':
                fea_hooks = get_feas_by_hook(net, extract_module=['avg_pool'])
            elif args.dataset == 'imagenet':
                fea_hooks = get_feas_by_hook(net, extract_module=['avgpool'])

            output = net(inputs)
            
            features = fea_hooks[0].fea.squeeze()
            # print(features.shape)
            # print(fdsds)

            forward_feature.append(features.detach().cpu())
            label.append(targets.detach().cpu())

        forward_feature = torch.cat(forward_feature, 0)
        label = torch.cat(label, dim=0)
        forward_feature = forward_feature.numpy()
        label = label.numpy()
        print(forward_feature.shape, label.shape)
        # np.save(save_path + save_name + '_foward_feature'+check+'.npy', forward_feature)
        # np.save(save_path + save_name + '_label'+check+'.npy', label)
    else:
        forward_feature = np.load(save_path + save_name + '_foward_feature'+check+'.npy')
        label = np.load(save_path + save_name + '_label'+check+'.npy')
    
    dataset = MyDataset(forward_feature, label)
    feature_dataloader = torch.utils.data.DataLoader(dataset, batch_size=args.batch_size, shuffle=False, num_workers=4)

    return forward_feature, label, feature_dataloader

def knn(feat_log, feat_log_val, K=5):
    normalizer = lambda x: x / (np.linalg.norm(x, ord=2, axis=-1, keepdims=True) + 1e-10)
    prepos_feat = lambda x: np.ascontiguousarray(normalizer(x))# Last Layer only

    ftrain = prepos_feat(feat_log)
    ftest = prepos_feat(feat_log_val)

    #################### KNN score OOD detection #################
    index = faiss.IndexFlatL2(ftrain.shape[1])
    index.add(ftrain)
   
    D, _ = index.search(ftest, K)
    scores_in = D[:,-1]

    return scores_in

def train_select(epoch, gamma, train_forward_feature):
    net.train()
    loss_avg = 0.0
    train_loader_out.dataset.offset = np.random.randint(len(train_loader_in.dataset))
    for batch_idx, (in_set, out_set) in enumerate(zip(train_loader_in, train_loader_out)):

        data, target = torch.cat((in_set[0], out_set[0]), 0), in_set[1]
        data, target = data.cuda(), target.cuda()

        # x, emb = net.pred_emb(data)
        # train_forward_feature, train_label, feature_train_dataloader = obtain_feature_loader(net, train_loader_in, save_dir, args.dataset+'_train', args, check)
        _, test_feature = net.pred_emb(data[:len(in_set[0])])
        # confs = knn(train_forward_feature, test_feature.detach().cpu(), K=5)
        _, ood_feature = net.pred_emb(data[len(in_set[0]):])
        ood_confs = knn(test_feature.detach().cpu(), ood_feature.detach().cpu(), K=5)
        # threshold = np.percentile(confs, 0.95*100) # percent的数小于threshold
        # index = np.argwhere(ood_confs<=threshold).flatten()
        index = np.argsort(ood_confs)
        select_ood_data = data[len(in_set[0]):][index[0:256]]
        select_data = torch.cat((data[:len(in_set[0])], select_ood_data), dim=0)
        # print(select_data.shape)
        
        x, emb = net.pred_emb(select_data)
        l_ce = F.cross_entropy(x[:len(in_set[0])], target)
        l_oe_old = - (x[len(in_set[0]):].mean(1) - torch.logsumexp(x[len(in_set[0]):], dim=1)).mean()

        emb_oe = emb[len(in_set[0]):].detach()
        emb_bias = torch.rand_like(emb_oe) * 0.0001

        for _ in range(args.iter):
            emb_bias.requires_grad_()

            x_aug = net.fc(emb_bias + emb_oe)
            l_sur = - (x_aug.mean(1) - torch.logsumexp(x_aug, dim=1)).mean()
            r_sur = (emb_bias.abs()).mean(-1).mean()
            l_sur = l_sur - r_sur * gamma
            grads = torch.autograd.grad(l_sur, [emb_bias])[0]
            grads /= (grads ** 2).sum(-1).sqrt().unsqueeze(1)
            
            emb_bias = emb_bias.detach() + args.strength * grads.detach() # + torch.randn_like(grads.detach()) * 0.000001
            optimizer.zero_grad()
        
        gamma -= args.beta * (args.rho - r_sur.detach())
        gamma = gamma.clamp(min=0.0, max=args.gamma)
        if epoch >= args.warmup:
            x_oe = net.fc(emb[len(in_set[0]):] + emb_bias)
        else:    
            x_oe = net.fc(emb[len(in_set[0]):])
        
        l_oe = - (x_oe.mean(1) - torch.logsumexp(x_oe, dim=1)).mean()
        loss = l_ce + .5 * l_oe
    
        optimizer.zero_grad()
        loss.backward()
        optimizer.step()

        loss_avg = loss_avg * 0.8 + float(loss) * 0.2
        sys.stdout.write('\r epoch %2d %d/%d loss %.2f' %(epoch, batch_idx + 1, len(train_loader_in), loss_avg))
        scheduler.step()
    return gamma

def train_adv(epoch, gamma):

    net.train()

    loss_avg = 0.0
    train_loader_out.dataset.offset = np.random.randint(len(train_loader_in.dataset))
    for batch_idx, (in_set, out_set) in enumerate(zip(train_loader_in, train_loader_out)):

        data, target = torch.cat((in_set[0], out_set[0]), 0), in_set[1]
        data, target = data.cuda(), target.cuda()

        ##################################### 对抗样本
        clean_x = in_set[0].cuda()
        clean_x.requires_grad=True
        output = net(clean_x)
        loss_ce = F.cross_entropy(output, target)
        optimizer.zero_grad()
        loss_ce.backward()
        lr = 1
        adv_x = (clean_x + lr*clean_x.grad.data).detach().cpu()
        # print(clean_x.grad.data.min(), clean_x.grad.data.max())
        # print(clean_x.max(), adv_x.max(), clean_x.min(), adv_x.min())
        # print(fdsfsd)
        data = torch.cat((torch.cat((in_set[0], adv_x), 0), out_set[0]), 0).cuda()
        ########################################################################

        x, emb = net.pred_emb(data)
        l_ce = F.cross_entropy(x[:len(in_set[0])], target)
        l_oe_adv = - (x[len(in_set[0]):2*len(in_set[0])].mean(1) - torch.logsumexp(x[len(in_set[0]):2*len(in_set[0])], dim=1)).mean()
        l_oe_old = - (x[2*len(in_set[0]):].mean(1) - torch.logsumexp(x[2*len(in_set[0]):], dim=1)).mean()

        # emb_oe = emb[2*len(in_set[0]):].detach()
        # emb_bias = torch.rand_like(emb_oe) * 0.0001

        # for _ in range(args.iter):
        #     emb_bias.requires_grad_()

        #     x_aug = net.fc(emb_bias + emb_oe)
        #     l_sur = - (x_aug.mean(1) - torch.logsumexp(x_aug, dim=1)).mean()
        #     r_sur = (emb_bias.abs()).mean(-1).mean()
        #     l_sur = l_sur - r_sur * gamma
        #     grads = torch.autograd.grad(l_sur, [emb_bias])[0]
        #     grads /= (grads ** 2).sum(-1).sqrt().unsqueeze(1)
            
        #     emb_bias = emb_bias.detach() + args.strength * grads.detach() # + torch.randn_like(grads.detach()) * 0.000001
        #     optimizer.zero_grad()
        
        # gamma -= args.beta * (args.rho - r_sur.detach())
        # gamma = gamma.clamp(min=0.0, max=args.gamma)
        # if epoch >= args.warmup:
        #     x_oe = net.fc(emb[2*len(in_set[0]):] + emb_bias)
        # else:    
        #     x_oe = net.fc(emb[2*len(in_set[0]):])
        
        # l_oe = - (x_oe.mean(1) - torch.logsumexp(x_oe, dim=1)).mean()

        # loss = l_ce + .5 * l_oe

        # loss = l_ce + .5 * l_oe_old + .5 * l_oe_adv
        loss = l_ce + l_oe_adv
    
        optimizer.zero_grad()
        loss.backward()
        optimizer.step()

        loss_avg = loss_avg * 0.8 + float(loss) * 0.2
        sys.stdout.write('\r epoch %2d %d/%d loss %.2f' %(epoch, batch_idx + 1, len(train_loader_in), loss_avg))
        scheduler.step()
    return gamma

def train_adv_2(epoch, gamma):

    net.train()

    loss_avg = 0.0
    train_loader_out.dataset.offset = np.random.randint(len(train_loader_in.dataset))
    for batch_idx, (in_set, out_set) in enumerate(zip(train_loader_in, train_loader_out)):

        # data, target = torch.cat((in_set[0], out_set[0]), 0), in_set[1]
        data, target = torch.cat((in_set[0], in_set[0]), 0), in_set[1]
        data, target = data.cuda(), target.cuda()

        x, emb = net.pred_emb(data)
        l_ce = F.cross_entropy(x[:len(in_set[0])], target)
        l_oe_old = - (x[len(in_set[0]):].mean(1) - torch.logsumexp(x[len(in_set[0]):], dim=1)).mean()

        emb_oe = emb[len(in_set[0]):].detach()
        emb_bias = torch.rand_like(emb_oe) * 0.0001

        for _ in range(args.iter):
            emb_bias.requires_grad_()
            x_aug = net.fc(emb_bias + emb_oe)
            # l_sur = - (x_aug.mean(1) - torch.logsumexp(x_aug, dim=1)).mean()
            l_sur = F.cross_entropy(x_aug, target)
            r_sur = (emb_bias.abs()).mean(-1).mean()
            l_sur = l_sur - r_sur * gamma
            grads = torch.autograd.grad(l_sur, [emb_bias])[0]
            grads /= (grads ** 2).sum(-1).sqrt().unsqueeze(1)
            
            emb_bias = emb_bias.detach() + args.strength * grads.detach() # + torch.randn_like(grads.detach()) * 0.000001
            optimizer.zero_grad()
        
        gamma -= args.beta * (args.rho - r_sur.detach())
        gamma = gamma.clamp(min=0.0, max=args.gamma)
        if epoch >= args.warmup:
            x_oe = net.fc(emb[len(in_set[0]):] + emb_bias)
        else:    
            x_oe = net.fc(emb[len(in_set[0]):])
        
        l_oe = - (x_oe.mean(1) - torch.logsumexp(x_oe, dim=1)).mean()
        loss = l_ce + .5 * l_oe
    
        optimizer.zero_grad()
        loss.backward()
        optimizer.step()

        loss_avg = loss_avg * 0.8 + float(loss) * 0.2
        sys.stdout.write('\r epoch %2d %d/%d loss %.2f' %(epoch, batch_idx + 1, len(train_loader_in), loss_avg))
        scheduler.step()
    return gamma

def train_feature_orth(epoch, gamma):

    net.train()

    loss_avg = 0.0
    train_loader_out.dataset.offset = np.random.randint(len(train_loader_in.dataset))
    for batch_idx, (in_set, out_set) in enumerate(zip(train_loader_in, train_loader_out)):

        data, target = torch.cat((in_set[0], out_set[0]), 0), in_set[1]
        data, target = data.cuda(), target.cuda()

        x, emb = net.pred_emb(data)
        l_ce = F.cross_entropy(x[:len(in_set[0])], target)
        l_oe_old = - (x[len(in_set[0]):].mean(1) - torch.logsumexp(x[len(in_set[0]):], dim=1)).mean()

        # # print(net.fc.weight.data.shape)
        # # print(fdsfsd)
        emb = emb/torch.norm(emb, dim=1, keepdim=True)
        num = np.arange(0, in_set[0].shape[0], 1)
        # feature_parallel_loss = -torch.norm((emb[:len(in_set[0])] @ net.fc.weight.data.T)[num,target], p=1)
        # feature_orth_loss = torch.norm((emb[len(in_set[0]):] @ net.fc.weight.data.T), p=1, dim=1).mean() #- torch.norm(emb[len(in_set[0]):], dim=1).mean()
        # print(torch.norm(emb[len(in_set[0]):]), torch.norm(net.fc.weight.data))
        # emb_loss = torch.norm(torch.norm(emb, dim=1),p=1)
        # weight_loss = torch.norm(net.fc.weight.data)
        # # print(feature_orth_loss.shape, feature_parallel_loss.shape)
        # # print(fdsfsd)
        loss_parallel = 0
        for k in range(in_set[0].shape[0]):
            # print(torch.norm(emb[:len(in_set[0])][k]), torch.norm(net.fc.weight.data[target[k]]))
            # print(fsdfs)
            normalize = torch.norm(net.fc.weight.data[target[k]]).detach()
            loss_parallel += torch.norm(normalize*emb[:len(in_set[0])][k] - net.fc.weight.data[target[k]])

        loss_parallel = loss_parallel/in_set[0].shape[0]
        # loss = l_ce + .5 * l_oe_old + .5 * feature_orth_loss + .5 * feature_parallel_loss + .5 * weight_loss #+ .5 * emb_loss
        loss = l_ce + .5 * l_oe_old + loss_parallel   
    
        optimizer.zero_grad()
        loss.backward()
        optimizer.step()

        loss_avg = loss_avg * 0.8 + float(loss) * 0.2
        # sys.stdout.write('\r epoch %2d %d/%d loss %.2f' %(epoch, batch_idx + 1, len(train_loader_in), loss_avg))
        sys.stdout.write('\r epoch %2d %d/%d parloss %.2f loss %.2f' %(epoch, batch_idx + 1, len(train_loader_in), loss_parallel, loss))
        scheduler.step()
    return gamma

def train_feature_parallel(epoch, gamma):

    net.train()

    loss_avg = 0.0
    train_loader_out.dataset.offset = np.random.randint(len(train_loader_in.dataset))
    for batch_idx, (in_set, out_set) in enumerate(zip(train_loader_in, train_loader_out)):

        data, target = torch.cat((in_set[0], out_set[0]), 0), in_set[1]
        data, target = data.cuda(), target.cuda()

        x, emb = net.pred_emb(data)
        l_ce = F.cross_entropy(x[:len(in_set[0])], target)
        l_oe_old = - (x[len(in_set[0]):].mean(1) - torch.logsumexp(x[len(in_set[0]):], dim=1)).mean()

        ############################################################################################################
        if epoch>=25:
            emb = emb/torch.norm(emb, dim=1, keepdim=True)
            a = net.fc.weight.data/torch.norm(net.fc.weight.data, dim=1, keepdim=True)
            loss_parallel = 0
            for k in range(in_set[0].shape[0]):
                loss_parallel += -(emb[:len(in_set[0])][k] @ a[target[k]])
            loss_parallel = loss_parallel/in_set[0].shape[0]
            loss_orth = torch.norm((emb[len(in_set[0]):] @ a.T), p=1, dim=1).mean()

            loss = l_ce + 0.5*l_oe_old + loss_orth + loss_parallel
        else:
            loss = l_ce + 0.5*l_oe_old

        ############################################################################################################
        optimizer.zero_grad()
        loss.backward()
        optimizer.step()

        loss_avg = loss_avg * 0.8 + float(loss) * 0.2
        # sys.stdout.write('\r epoch %2d %d/%d loss %.2f' %(epoch, batch_idx + 1, len(train_loader_in), loss_avg))
        sys.stdout.write('\r epoch %2d %d/%d parloss %.2f orthloss %.2f loss %.2f' %(epoch, batch_idx + 1, len(train_loader_in), loss_parallel, loss_orth, l_ce + 0.5*l_oe_old))
        scheduler.step()
    return gamma

def train_feature_parallel_aug(epoch, gamma):

    net.train()

    loss_avg = 0.0
    train_loader_out.dataset.offset = np.random.randint(len(train_loader_in.dataset))
    for batch_idx, (in_set, out_set) in enumerate(zip(train_loader_in, train_loader_out)):

        data, target = torch.cat((in_set[0], out_set[0]), 0), in_set[1]
        data, target = data.cuda(), target.cuda()

        x, emb = net.pred_emb(data)
        l_ce = F.cross_entropy(x[:len(in_set[0])], target)
        l_oe_old = - (x[len(in_set[0]):].mean(1) - torch.logsumexp(x[len(in_set[0]):], dim=1)).mean()

        ############################################################################################################
        emb_norm = emb/torch.norm(emb, dim=1, keepdim=True)
        a = net.fc.weight.data/torch.norm(net.fc.weight.data, dim=1, keepdim=True)

        loss_parallel = 0
        for k in range(in_set[0].shape[0]):
            loss_parallel += -(emb_norm[:len(in_set[0])][k] @ a[target[k]])
        loss_parallel = loss_parallel/in_set[0].shape[0]

        loss_orth = torch.norm((emb_norm[len(in_set[0]):] @ a.T), p=1, dim=1).mean()
        ############################################################################################################
        emb_oe = emb[len(in_set[0]):].detach()
        emb_bias = torch.rand_like(emb_oe) * 0.0001

        for _ in range(args.iter):
            emb_bias.requires_grad_()

            x_aug = net.fc(emb_bias + emb_oe)
            l_sur = - (x_aug.mean(1) - torch.logsumexp(x_aug, dim=1)).mean()
            r_sur = (emb_bias.abs()).mean(-1).mean()
            l_sur = l_sur - r_sur * gamma
            grads = torch.autograd.grad(l_sur, [emb_bias])[0]
            grads /= (grads ** 2).sum(-1).sqrt().unsqueeze(1)
            
            emb_bias = emb_bias.detach() + args.strength * grads.detach() # + torch.randn_like(grads.detach()) * 0.000001
            optimizer.zero_grad()
        
        gamma -= args.beta * (args.rho - r_sur.detach())
        gamma = gamma.clamp(min=0.0, max=args.gamma)
        
        ood_adv_emb = emb[len(in_set[0]):] + emb_bias
        ood_adv_emb = ood_adv_emb/torch.norm(ood_adv_emb, dim=1, keepdim=True)
        loss_orth_aug = torch.norm((ood_adv_emb @ a.T), p=1, dim=1).mean()
        ############################################################################################################
        if epoch>=25 and epoch <35:
            loss = l_ce + 0.5*l_oe_old + loss_orth + loss_parallel
        elif epoch>=35:
            loss = l_ce + 0.5*l_oe_old + loss_orth + loss_parallel + loss_orth_aug
        else:
            loss = l_ce + 0.5*l_oe_old

        ############################################################################################################
        optimizer.zero_grad()
        loss.backward()
        optimizer.step()

        loss_avg = loss_avg * 0.8 + float(loss) * 0.2
        # sys.stdout.write('\r epoch %2d %d/%d loss %.2f' %(epoch, batch_idx + 1, len(train_loader_in), loss_avg))
        sys.stdout.write('\r epoch %2d %d/%d parloss %.2f orthloss %.2f loss %.2f' %(epoch, batch_idx + 1, len(train_loader_in), loss_orth, loss_orth_aug, l_ce + 0.5*l_oe_old))
        scheduler.step()
    return gamma

def train_feature_parallel_ablation(epoch, gamma):
    net.train()
    loss_avg = 0.0
    train_loader_out.dataset.offset = np.random.randint(len(train_loader_in.dataset))
    for batch_idx, (in_set, out_set) in enumerate(zip(train_loader_in, train_loader_out)):

        data, target = torch.cat((in_set[0], out_set[0]), 0), in_set[1]
        data, target = data.cuda(), target.cuda()

        x, emb = net.pred_emb(data)
        l_ce = F.cross_entropy(x[:len(in_set[0])], target)
        l_oe_old = - (x[len(in_set[0]):].mean(1) - torch.logsumexp(x[len(in_set[0]):], dim=1)).mean()

        ############################################################################################################
        emb = emb/torch.norm(emb, dim=1, keepdim=True)
        a = net.fc.weight.data/torch.norm(net.fc.weight.data, dim=1, keepdim=True)
        loss_parallel = 0
        for k in range(in_set[0].shape[0]):
            loss_parallel += -(emb[:len(in_set[0])][k] @ a[target[k]])
        loss_parallel = loss_parallel/in_set[0].shape[0]
        loss_orth = torch.norm((emb[len(in_set[0]):] @ a.T), p=1, dim=1).mean()
        
        # ### 欧式距离
        # a = net.fc.weight.data
        # loss_parallel = 0
        # for k in range(in_set[0].shape[0]):
        #     loss_parallel += torch.norm((emb[:len(in_set[0])][k] - a[target[k]]))
        # loss_parallel = loss_parallel/in_set[0].shape[0]
        # loss_orth = 0
        # for k in range(out_set[0].shape[0]):
        #     loss_orth += -torch.norm(emb[len(in_set[0]):][k] - a, dim=1).mean()
        # loss_orth = loss_orth/out_set[0].shape[0]
        ############################################################################################################
        if epoch>=25:  
            # loss = l_ce + 0.5*l_oe_old + loss_orth + loss_parallel
            # loss = l_ce + 0.5*l_oe_old + loss_orth
            loss = l_ce + loss_parallel + loss_orth
        else:
            # loss = l_ce + 0.5*l_oe_old
            loss = l_ce + loss_parallel

        ############################################################################################################
        optimizer.zero_grad()
        loss.backward()
        optimizer.step()

        loss_avg = loss_avg * 0.8 + float(loss) * 0.2
        sys.stdout.write('\r epoch %2d %d/%d parloss %.2f orthloss %.2f loss %.2f' %(epoch, batch_idx + 1, len(train_loader_in), loss_parallel, loss_orth, l_ce + 0.5*l_oe_old))
        scheduler.step()
    return gamma

def train_feature_parallel_training_time(epoch, gamma):
    net.train()
    loss_avg = 0.0
    train_loader_out.dataset.offset = np.random.randint(len(train_loader_in.dataset))
    for batch_idx, (in_set, out_set) in enumerate(zip(train_loader_in, train_loader_out)):

        data, target = torch.cat((in_set[0], out_set[0]), 0), in_set[1]
        data, target = data.cuda(), target.cuda()

        x, emb = net.pred_emb(data)
        l_ce = F.cross_entropy(x[:len(in_set[0])], target)
        l_oe_old = - (x[len(in_set[0]):].mean(1) - torch.logsumexp(x[len(in_set[0]):], dim=1)).mean()


        if epoch>=25:
            emb = emb/torch.norm(emb, dim=1, keepdim=True)
            a = net.fc.weight.data/torch.norm(net.fc.weight.data, dim=1, keepdim=True)
            loss_parallel = 0
            for k in range(in_set[0].shape[0]):
                loss_parallel += -(emb[:len(in_set[0])][k] @ a[target[k]])
            loss_parallel = loss_parallel/in_set[0].shape[0]
            loss_orth = torch.norm((emb[len(in_set[0]):] @ a.T), p=1, dim=1).mean()
            loss = l_ce + 0.5*l_oe_old + loss_orth + loss_parallel
        else:
            loss = l_ce + 0.5*l_oe_old

        ############################################################################################################
        optimizer.zero_grad()
        loss.backward()
        optimizer.step()

        loss_avg = loss_avg * 0.8 + float(loss) * 0.2
        sys.stdout.write('\r epoch %2d %d/%d loss %.2f' %(epoch, batch_idx + 1, len(train_loader_in), loss_avg))
        # sys.stdout.write('\r epoch %2d %d/%d parloss %.2f orthloss %.2f loss %.2f' %(epoch, batch_idx + 1, len(train_loader_in), loss_parallel, loss_orth, l_ce + 0.5*l_oe_old))
        scheduler.step()
    return gamma


def train_oe(epoch, gamma):

    net.train()

    loss_avg = 0.0
    train_loader_out.dataset.offset = np.random.randint(len(train_loader_in.dataset))
    for batch_idx, (in_set, out_set) in enumerate(zip(train_loader_in, train_loader_out)):

        data, target = torch.cat((in_set[0], out_set[0]), 0), in_set[1]
        data, target = data.cuda(), target.cuda()

        fea_hooks = get_feas_by_hook(net, extract_module=['avgpool'])
        x = net(data)
        emb = fea_hooks[0].fea.squeeze()
        print(emb.shape)
        print(fsdfs)

        # x, emb = net.pred_emb(data)
        l_ce = F.cross_entropy(x[:len(in_set[0])], target)
        l_oe_old = - (x[len(in_set[0]):].mean(1) - torch.logsumexp(x[len(in_set[0]):], dim=1)).mean()

        loss = l_ce + .5 * l_oe_old
    
        optimizer.zero_grad()
        loss.backward()
        optimizer.step()

        loss_avg = loss_avg * 0.8 + float(loss) * 0.2
        sys.stdout.write('\r epoch %2d %d/%d loss %.2f' %(epoch, batch_idx + 1, len(train_loader_in), loss_avg))
        scheduler.step()
    return gamma
    
def test_loss():
    net.eval()
    loss_avg = 0.0
    train_loader_out.dataset.offset = np.random.randint(len(train_loader_in.dataset))

    for batch_idx, (in_set, out_set) in enumerate(zip(train_loader_in, train_loader_out)):
        data, target = torch.cat((in_set[0], out_set[0]), 0), in_set[1]
        data, target = data.cuda(), target.cuda()

        x = net(data)
        l_ce = F.cross_entropy(x[:len(in_set[0])], target)
        l_oe_old = - (x[len(in_set[0]):].mean(1) - torch.logsumexp(x[len(in_set[0]):], dim=1)).mean()
        loss = l_ce + .5 * l_oe_old
        
        loss_avg = loss_avg * 0.8 + float(loss) * 0.2
        sys.stdout.write('\r %d/%d loss %.2f' %(batch_idx + 1, len(train_loader_in), loss_avg))

    return


# net = WideResNet(args.layers, num_classes, args.widen_factor, dropRate=args.droprate).cuda()
# if args.dataset == 'cifar10':
#     model_path = '../model/cifar10_wrn_pretrained_epoch_99.pt'
# else:
#     model_path = '../model/cifar100_wrn_pretrained_epoch_99.pt'

import torchvision
from torchvision import models
net = models.resnet50(weights=torchvision.models.ResNet50_Weights.IMAGENET1K_V1).cuda()


optimizer = torch.optim.SGD(net.parameters(), args.learning_rate, momentum=args.momentum, weight_decay=args.decay, nesterov=True)
def cosine_annealing(step, total_steps, lr_max, lr_min):
    return lr_min + (lr_max - lr_min) * 0.5 * (1 + np.cos(step / total_steps * np.pi))
scheduler = torch.optim.lr_scheduler.LambdaLR(optimizer, lr_lambda=lambda step: cosine_annealing(step, args.epochs * len(train_loader_in), 1, 1e-6 / args.learning_rate))
# net.load_state_dict(torch.load(model_path))
print('\n acc:', test())

##################################################################   
# net.load_state_dict(torch.load('./models/'+ args.dataset + '_bz' + str(args.oe_batch_size) + '_feature_po_2_v11_5.pt'))
# net.eval()
# in_score = get_ood_scores(test_loader, in_dist=True)
# metric_ll = []
# metric_ll.append(get_and_print_results(svhn_loader, in_score))
# metric_ll.append(get_and_print_results(lsunc_loader, in_score))
# metric_ll.append(get_and_print_results(isun_loader, in_score))
# metric_ll.append(get_and_print_results(texture_loader, in_score))
# metric_ll.append(get_and_print_results(places365_loader, in_score))
# print('\n & %.2f & %.2f & %.2f' % tuple((100 * torch.Tensor(metric_ll).mean(0)).tolist()))
# # test_loss()
# print('\n acc:', test())
# print(fdsfsd)  
##################################################################
import time
gamma = 0.01
# start = time.time()
for epoch in range(args.epochs):
    # gamma = train_sam(epoch, gamma, args.sam_type)
    # train_forward_feature, train_label, feature_train_dataloader = obtain_feature_loader(net, train_loader_in, save_dir, args.dataset+'_train', args, check)
    # gamma  = train_select(epoch, gamma, train_forward_feature=None)
    # gamma = train_adv_2(epoch, gamma)
    # gamma = train_feature_orth(epoch, gamma)

    # gamma = train_feature_parallel(epoch, gamma)
    # gamma = train_feature_parallel_aug(epoch, gamma)
    # gamma = train_feature_parallel_ablation(epoch, gamma)
    # gamma = train_feature_parallel_training_time(epoch, gamma)
    # version = 'v11_4'
    # net.load_state_dict(torch.load('./models/'+ args.dataset + '_bz' + str(args.oe_batch_size) + '_feature_po_2_'+version+'.pt'))
    # net.load_state_dict(torch.load('./models/'+ args.dataset + '_baseline.pt'))
    # net.load_state_dict(torch.load('../model/'+ args.dataset + '_baseline_oe.pt'))
    # print('version:', version)
    gamma = train_oe(epoch, gamma)
    print('\n acc:', test())
   
    if epoch % 5 == 4: 
    # if True:
        net.eval()
        in_score = get_ood_scores(test_loader, in_dist=True)
        metric_ll = []
        metric_ll.append(get_and_print_results(inat_loader, in_score))
        metric_ll.append(get_and_print_results(sun50_loader, in_score))
        metric_ll.append(get_and_print_results(places50_loader, in_score))
        metric_ll.append(get_and_print_results(dtd_loader, in_score))
        print('\n & %.2f & %.2f & %.2f' % tuple((100 * torch.Tensor(metric_ll).mean(0)).tolist()))
   
    torch.save(net.state_dict(), './models/'+ args.dataset + '_bz' + str(args.oe_batch_size) + '_oe_v1.pt')

# end = time.time()
# print(end-start, 's')
# print((end-start)/60, 'min')
# print(((end-start)/60)/60, 'h')

############# oe
# v1: bz 64, oe_bz 64, lr 0.01, epochs 20