# Copyright (c) Microsoft Corporation.
# SPDX-License-Identifier: Apache-2.0

# DeepSpeed Team

import torch
import copy


class Experts(torch.nn.Module):

    def __init__(self, expert, num_local_experts=1, expert_group_name=None):
        super(Experts, self).__init__()

        self.deepspeed_experts = torch.nn.ModuleList([copy.deepcopy(expert) for i in range(num_local_experts)])
        self.num_local_experts = num_local_experts

        # TODO: revisit allreduce for moe.gate...
        for expert in self.deepspeed_experts:
            # TODO: Create param groups to handle expert + data case (e.g. param.group = moe_group)
            for name, param in expert.named_parameters():
                param.allreduce = False
                param.group_name = expert_group_name

    def forward(self, inputs):
        chunks = inputs.chunk(self.num_local_experts, dim=1)    ## dim=1是数据token数所在的维度
        expert_outputs = []
        for chunk, expert in zip(chunks, self.deepspeed_experts):
            out = expert(chunk)
            if type(out) is tuple:
                out = out[0]  # Ignore the bias term for now
            expert_outputs += [out]

        expert_output = torch.cat(expert_outputs, dim=1)
        return expert_output

    def cosine(self, a, b):
        # print(a.shape, b.shape)
        a = a.flatten()
        b = b.flatten()
        cos = torch.square(torch.sum(a*b)/(torch.norm(a)*torch.norm(b)))
        # print('cos:', cos)
        # print(sdfdsfsd)
        return cos

    ## 专家多样性正则化
    def orth_for_diversity(self):
        loss = 0
        num = 0
        num_local_experts = self.num_local_experts
        for i in range(num_local_experts):
            for j in range(i+1, num_local_experts):
                loss += self.cosine(self.deepspeed_experts[i].c_proj.weight, self.deepspeed_experts[j].c_proj.weight)
                num += 1
        # num = (num_local_experts)*(num_local_experts)/2
        loss /= num      
        return loss
