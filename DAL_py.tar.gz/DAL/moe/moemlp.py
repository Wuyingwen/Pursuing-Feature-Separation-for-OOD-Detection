import torch
import torch.nn as nn
import re
from typing import List, Optional
import torch.nn.functional as F
from einops import rearrange, repeat, reduce, pack, unpack

import torch
import torch.nn as nn
import re


class MLPMoE(nn.Module):
    def __init__(self, num_experts, num_selected, mm_channels, channels):
        super().__init__()
        self.num_experts = num_experts
        self.num_selected = num_selected
        self.mm_channels = mm_channels  ## mm_hidden_size
        self.channels = channels  ## hidden_size

        self.gate = nn.Linear(mm_channels, num_experts, bias=False)
        # self.gate = nn.Linear(1, num_experts, bias=False)
        self.experts = nn.ModuleList([nn.Linear(mm_channels, channels) for _ in range(num_experts)])

    def forward(self, x_img):
        # x_img: [bt, n, c], n is token number, video
        # x_img: [bz, dim, 1] 或 x_img: [1, bz, dim]
        x_img = x_img.unsqueeze(0)
        # print(x_img.shape)

        gate_logits = self.gate(x_img)  ## gate_logits:(bz, experts)

        router_z_loss = torch.logsumexp(gate_logits, dim = -1)
        router_z_loss = torch.square(router_z_loss)            
        router_z_loss = router_z_loss.mean()
        
        gate_softmax = F.softmax(gate_logits, dim=-1, dtype=torch.float).to(x_img.dtype)

        # density_1_proxy = reduce(gate_softmax, 'bz experts -> experts', 'mean') ## 专家被激活的平均概率
        density_1_proxy = reduce(gate_softmax, '... n e -> ... e', 'mean')

        weights, selected_experts = torch.topk(gate_softmax, self.num_selected)

        one_hot_gate_indices = F.one_hot(rearrange(selected_experts, '... k -> k ...'), self.num_experts).float()[0]
        density_1 = reduce(one_hot_gate_indices, '... n e -> ... e', 'mean')    ## 每个专家处理的sample比例

        balance_loss = (density_1_proxy * density_1).mean() * float(self.num_experts ** 2)

        weights = weights / torch.sum(weights, dim=-1, keepdim=True).to(x_img.dtype)
        
        results = torch.zeros((x_img.shape[0], x_img.shape[1], self.channels)).to(x_img.device, x_img.dtype)
        for b in range(x_img.shape[0]):
            for i, expert in enumerate(self.experts):
                token_idx, nth_expert = torch.where(selected_experts[b] == i)
                results[b][token_idx] += weights[b][token_idx, nth_expert, None] * expert(x_img[b][token_idx])
        
        results = results.squeeze(0)
        # print('result:', results.shape)
        # print(fsdfsd)
        self.balance_loss = balance_loss
        self.router_z_loss = router_z_loss

        return results
    
    def balance_loss_cal(self):
        return self.balance_loss
    
    def router_z_loss_cal(self):
        return self.router_z_loss

    def cosine(self, a, b):
        a = a.flatten()
        b = b.flatten()
        cos = torch.abs(torch.sum(a*b)/(torch.norm(a)*torch.norm(b)))
        return cos

    ## 专家多样性正则化
    def orth_for_diversity(self):
        loss = 0
        num = 0
        for i in range(self.num_experts):
            for j in range(i+1, self.num_experts):
                loss += self.cosine(self.experts[i].weight, self.experts[j].weight)
                num += 1
        loss /= num      
        return loss
