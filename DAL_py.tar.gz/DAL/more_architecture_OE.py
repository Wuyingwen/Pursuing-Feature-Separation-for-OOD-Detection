# -*- coding: utf-8 -*-
### 查看 OOD feature 与 ID feature 的不同之处，能否约束扩大不同之处。
### 不同OOD样本的featrue的类似之处，比如约束特征上的对抗噪声在低维子空间内
### 验证select data算法，比如POEM的有效性（查看github代码）。直接在特征空间选择OOD data，而不在输出空间。
# CUDA_VISIBLE_DEVICES=1 python main_sam.py cifar10 --learning_rate=0.07 --gamma=10 --beta=.01  --rho=10  --iter=10 --epochs 50 --version v1
# CUDA_VISIBLE_DEVICES=0 python main_sam.py cifar100  --learning_rate=0.07 --gamma=10 --beta=.005  --rho=10  --iter=10 --epochs 50 --version v1

import numpy as np
import sys
import argparse
import torch
import torch.nn as nn
import torch.backends.cudnn as cudnn
import torchvision.transforms as trn
import torchvision.datasets as dset
import torch.nn.functional as F
from models.wrn import WideResNet
from models.densenet import densenet121
from models.resnet import resnet18

import os
import faiss
import torchvision

import utils.svhn_loader as svhn
from utils.display_results import get_measures, print_measures
from utils.tinyimages_80mn_loader import TinyImages
from visualize_utils import get_feas_by_hook

parser = argparse.ArgumentParser(description='DAL training procedure on the CIFAR benchmark',
                                 formatter_class=argparse.ArgumentDefaultsHelpFormatter)
parser.add_argument('dataset', type=str, choices=['cifar10', 'cifar100'],
                    help='Choose between CIFAR-10, CIFAR-100.')

# Optimization options
parser.add_argument('--epochs', '-e', type=int, default=50, help='Number of epochs to train.')
parser.add_argument('--learning_rate', '-lr', type=float, default=0.07, help='The initial learning rate.')
parser.add_argument('--batch_size', '-b', type=int, default=128, help='Batch size.')
parser.add_argument('--oe_batch_size', type=int, default=256, help='Batch size.')
parser.add_argument('--test_bs', type=int, default=200)
parser.add_argument('--momentum', type=float, default=0.9, help='Momentum.')
parser.add_argument('--decay', '-d', type=float, default=0.0005, help='Weight decay (L2 penalty).')
# WRN Architecture
parser.add_argument('--layers', default=40, type=int, help='total number of layers')
parser.add_argument('--widen-factor', default=2, type=int, help='widen factor')
parser.add_argument('--droprate', default=0.3, type=float, help='dropout probability')
# DAL hyper parameters
parser.add_argument('--gamma', default=10, type=float)
parser.add_argument('--beta',  default=0.01, type=float)
parser.add_argument('--rho',   default=10, type=float)
parser.add_argument('--strength', default=1, type=float)
parser.add_argument('--warmup', type=int, default=0)
parser.add_argument('--iter', default=10, type=int)
# Others
parser.add_argument('--out_as_pos', action='store_true', help='OE define OOD data as positive.')
parser.add_argument('--seed', type=int, default=222, help='seed for np(tinyimages80M sampling); 1|2|8|100|107')
# Energy-OE
parser.add_argument('--m_in', type=float, default=-25., help='default: -25. margin for in-distribution; above this value will be penalized')
parser.add_argument('--m_out', type=float, default=-7., help='default: -7. margin for out-distribution; below this value will be penalized')
parser.add_argument('--energy_beta', default=0.1, type=float, help='beta for energy fine tuning loss')
# ####
parser.add_argument('--version', type=str, default='v1', help='version')
####
parser.add_argument('--score_type', type=str, default='ours', help='version')
parser.add_argument('--stage2_start', default=25, type=int)
parser.add_argument('--alpha',   default=1, type=float)
parser.add_argument('--beta_ours',   default=1, type=float)
parser.add_argument('--model', type=str, default='wideresnet', help='version')


args = parser.parse_args()
torch.manual_seed(args.seed)
np.random.seed(args.seed)
torch.cuda.manual_seed(args.seed)

print(args.gamma, args.beta, args.rho)

cudnn.benchmark = True  # fire on all cylinders

class Logger(object):
    def __init__(self, logFile="Default.log"):
        self.terminal = sys.stdout
        self.log = open(logFile, 'a')

    def write(self, message):
        self.terminal.write(message)
        self.log.write(message)

    def flush(self):
        pass


# 使用 os.path.basename 获取文件名
file_name=os.path.basename(__file__).split(".")[0]
os.makedirs('./'+file_name+'/', exist_ok=True)
sys.stdout = Logger(file_name+'/output.log')

# mean and standard deviation of channels of CIFAR-10 images
mean = [x / 255 for x in [125.3, 123.0, 113.9]]
std = [x / 255 for x in [63.0, 62.1, 66.7]]

train_transform = trn.Compose([trn.RandomHorizontalFlip(), trn.RandomCrop(32, padding=4),
                                trn.ToTensor(), trn.Normalize(mean, std)])
test_transform = trn.Compose([trn.ToTensor(), trn.Normalize(mean, std)])

if args.dataset == 'cifar10':
    train_data_in = dset.CIFAR10('./data', train=True, transform=train_transform)
    test_data = dset.CIFAR10('./data', train=False, transform=test_transform)
    cifar_data = dset.CIFAR100('./data', train=False, transform=test_transform) 
    num_classes = 10
else:
    train_data_in = dset.CIFAR100('./data', train=True, transform=train_transform)
    test_data = dset.CIFAR100('./data', train=False, transform=test_transform)
    cifar_data = dset.CIFAR10('./data', train=False, transform=test_transform)
    num_classes = 100

# ood_data = TinyImages(transform=trn.Compose([trn.ToTensor(), trn.ToPILImage(), trn.RandomCrop(32, padding=4), trn.RandomHorizontalFlip(), trn.ToTensor(), trn.Normalize(mean, std)]), exclude_cifar = True)
transform_for_ood = trn.Compose([trn.ToTensor(), trn.ToPILImage(), trn.RandomCrop(32, padding=4), trn.RandomHorizontalFlip(), trn.ToTensor(), trn.Normalize(mean, std)])
ood_x = np.load('./data/300K_random_images.npy')
class MyDataset(torch.utils.data.Dataset):
    def __init__(self, data, label, transform=None):
        # if trans == True:
        #     ##### 归一化 0-1 之间， data.shape:[bz,dim], e.g. [50000,128]
        #     normalizer = lambda x: (x-np.expand_dims(x.min(1), axis=1))/np.expand_dims(x.max(1)-x.min(1), axis=1)
        #     data = normalizer(data)

        self.data = data
        self.label = torch.from_numpy(label)
        self.transform = transform
    def __getitem__(self, index):
        data = self.data[index]
        label = self.label[index]

        if self.transform!=None:
            data = self.transform(data)

        return data, label 

    def __len__(self):
        return self.data.shape[0]
ood_data = MyDataset(ood_x, np.zeros(ood_x.shape[0]), transform_for_ood)


train_loader_in = torch.utils.data.DataLoader(train_data_in, batch_size=args.batch_size, shuffle=True, num_workers=4, pin_memory=False)
train_loader_out = torch.utils.data.DataLoader(ood_data, batch_size=args.oe_batch_size, shuffle=True, num_workers=4, pin_memory=True)
test_loader = torch.utils.data.DataLoader(test_data, batch_size=args.batch_size, shuffle=False, num_workers=4, pin_memory=False)

texture_data = dset.ImageFolder(root="./data/ood_data/dtd/images", transform=trn.Compose([trn.Resize(32), trn.CenterCrop(32), trn.ToTensor(), trn.Normalize(mean, std)]))
svhn_data = svhn.SVHN(root='./data/ood_data/svhn/', split="test",transform=trn.Compose( [trn.ToTensor(), trn.Normalize(mean, std)]), download=False)
places365_data = dset.ImageFolder(root="./data/ood_data/places365", transform=trn.Compose([trn.Resize(32), trn.CenterCrop(32), trn.ToTensor(), trn.Normalize(mean, std)]))
lsunc_data = dset.ImageFolder(root="./data/ood_data/LSUN", transform=trn.Compose([trn.Resize(32), trn.ToTensor(), trn.Normalize(mean, std)]))
# lsunr_data = dset.ImageFolder(root="./data/LSUN_resize", transform=trn.Compose([trn.Resize(32), trn.ToTensor(), trn.Normalize(mean, std)]))
isun_data = dset.ImageFolder(root="./data/ood_data/iSUN",transform=trn.Compose([trn.ToTensor(), trn.Normalize(mean, std)]))

texture_loader = torch.utils.data.DataLoader(texture_data, batch_size=args.test_bs, shuffle=True, num_workers=4, pin_memory=False)
svhn_loader = torch.utils.data.DataLoader(svhn_data, batch_size=args.test_bs, shuffle=True, num_workers=4, pin_memory=False)
places365_loader = torch.utils.data.DataLoader(places365_data, batch_size=args.test_bs, shuffle=True, num_workers=4, pin_memory=False)
lsunc_loader = torch.utils.data.DataLoader(lsunc_data, batch_size=args.test_bs, shuffle=True, num_workers=4, pin_memory=False)
# lsunr_loader = torch.utils.data.DataLoader(lsunr_data, batch_size=args.test_bs, shuffle=True, num_workers=4, pin_memory=False)
isun_loader = torch.utils.data.DataLoader(isun_data, batch_size=args.test_bs, shuffle=True, num_workers=4, pin_memory=False)
cifar_loader = torch.utils.data.DataLoader(cifar_data, batch_size=args.test_bs, shuffle=True, num_workers=4, pin_memory=False)
ood_num_examples = len(test_data) // 5
expected_ap = ood_num_examples / (ood_num_examples + len(test_data))
concat = lambda x: np.concatenate(x, axis=0)
to_np = lambda x: x.data.cpu().numpy()


def knn(feat_log, feat_log_val, K=5):
    normalizer = lambda x: x / (np.linalg.norm(x, ord=2, axis=-1, keepdims=True) + 1e-10)
    # normalizer = lambda x: (x-np.expand_dims(x.min(1), axis=1))/np.expand_dims(x.max(1)-x.min(1), axis=1)
    prepos_feat = lambda x: np.ascontiguousarray(normalizer(x))# Last Layer only

    ftrain = prepos_feat(feat_log)
    ftest = prepos_feat(feat_log_val)
    #################### KNN score OOD detection #################
    index = faiss.IndexFlatL2(ftrain.shape[1])
    index.add(ftrain)

    D, _ = index.search(ftest, K)
    scores_in = -D[:,-1]
    return scores_in


def get_ood_scores(loader, score_type='msp', in_dist=False, **kwargs):
    _score = []
    net.eval()
    if score_type == "maha":
        with torch.enable_grad():
            num_classes = 10 if kwargs['data']=='cifar10' else 100
            conf = mahalanobis_official(net, loader, kwargs['sample_class_mean'], kwargs['variance'], num_classes, magnitude=0.01, data=kwargs['data'], in_dist=in_dist, ood_num_examples=ood_num_examples, test_bs=args.test_bs)
            _score.append(-conf)   
    elif score_type == "knn":
        if kwargs['data'] == 'cifar10' or kwargs['data'] == 'cifar100':
            K=1
        elif kwargs['data'] == 'imagenet':
            K=10
        test_feature = []
        for batch_idx, (data, target) in enumerate(loader):
            if batch_idx >= ood_num_examples // args.test_bs and in_dist is False:
                break
            data, target = data.cuda(), target.cuda()
            output, emb = net.pred_emb(data)
            test_feature.append(emb.cpu().detach())
        test_feature = torch.cat(test_feature, dim=0).numpy()
        conf = knn(kwargs['train_feature'], test_feature, K)
        _score.append(-conf)  
    else:
        with torch.no_grad():
            for batch_idx, (data, target) in enumerate(loader):
                if batch_idx >= ood_num_examples // args.test_bs and in_dist is False:
                    break
                data, target = data.cuda(), target.cuda()
                # output = net(data)
                output, emb = net.pred_emb(data)
                # print(output.shape, emb.shape)
                if score_type == 'msp':
                    smax = to_np(F.softmax(output, dim=1))
                    _score.append(-np.max(smax, axis=1))
                elif score_type == 'ours':
                    num_classes = 10 if kwargs['data']=='cifar10' else 100
                    target = torch.argmax(output.data, 1).detach()
                    emb = emb/torch.norm(emb, dim=1, keepdim=True)
                    a = net.fc.weight.data/torch.norm(net.fc.weight.data, dim=1, keepdim=True)
                    cosine = torch.norm((emb @ a.T), p=1, dim=1).cpu().detach().numpy()
                    #####
                    smax = to_np(F.softmax(output, dim=1))
                    msp = np.max(smax, axis=1)
                    #####
                    conf = msp + cosine
                    _score.append(-conf)
                elif score_type == 'energy':   
                    temper = 1
                    conf = temper * (torch.logsumexp(output / temper, dim=1))
                    _score.append(-conf.data.cpu().numpy())    

    if in_dist:
        return concat(_score).copy() # , concat(_right_score).copy(), concat(_wrong_score).copy()
    else:
        return concat(_score)[:ood_num_examples].copy()


def get_and_print_results(ood_loader, in_score, score_type='msp', num_to_avg=1, **kwargs):
    net.eval()
    aurocs, auprs, fprs = [], [], []
    for _ in range(num_to_avg):
        out_score = get_ood_scores(ood_loader, score_type, **kwargs)
        print('out_score.shape:', out_score.shape)
        if args.out_as_pos: # OE's defines out samples as positive
            measures = get_measures(out_score, in_score)
        else:
            measures = get_measures(-in_score, -out_score)
        aurocs.append(measures[0]); auprs.append(measures[1]); fprs.append(measures[2])
    auroc = np.mean(aurocs); aupr = np.mean(auprs); fpr = np.mean(fprs)
    print_measures(auroc, aupr, fpr, '')
    return fpr, auroc, aupr


def train(epoch, gamma):

    net.train()

    loss_avg = 0.0
    train_loader_out.dataset.offset = np.random.randint(len(train_loader_in.dataset))
    for batch_idx, (in_set, out_set) in enumerate(zip(train_loader_in, train_loader_out)):

        data, target = torch.cat((in_set[0], out_set[0]), 0), in_set[1]
        data, target = data.cuda(), target.cuda()

        x, emb = net.pred_emb(data)
        l_ce = F.cross_entropy(x[:len(in_set[0])], target)
        l_oe_old = - (x[len(in_set[0]):].mean(1) - torch.logsumexp(x[len(in_set[0]):], dim=1)).mean()

        emb_oe = emb[len(in_set[0]):].detach()
        emb_bias = torch.rand_like(emb_oe) * 0.0001

        for _ in range(args.iter):
            emb_bias.requires_grad_()

            x_aug = net.fc(emb_bias + emb_oe)
            l_sur = - (x_aug.mean(1) - torch.logsumexp(x_aug, dim=1)).mean()
            r_sur = (emb_bias.abs()).mean(-1).mean()
            l_sur = l_sur - r_sur * gamma
            grads = torch.autograd.grad(l_sur, [emb_bias])[0]
            grads /= (grads ** 2).sum(-1).sqrt().unsqueeze(1)
            
            emb_bias = emb_bias.detach() + args.strength * grads.detach() # + torch.randn_like(grads.detach()) * 0.000001
            optimizer.zero_grad()
        
        gamma -= args.beta * (args.rho - r_sur.detach())
        gamma = gamma.clamp(min=0.0, max=args.gamma)
        if epoch >= args.warmup:
            x_oe = net.fc(emb[len(in_set[0]):] + emb_bias)
        else:    
            x_oe = net.fc(emb[len(in_set[0]):])
        
        l_oe = - (x_oe.mean(1) - torch.logsumexp(x_oe, dim=1)).mean()
        loss = l_ce + .5 * l_oe
    
        optimizer.zero_grad()
        loss.backward()
        optimizer.step()

        loss_avg = loss_avg * 0.8 + float(loss) * 0.2
        sys.stdout.write('\r epoch %2d %d/%d loss %.2f' %(epoch, batch_idx + 1, len(train_loader_in), loss_avg))
        scheduler.step()
    return gamma

def test():
    net.eval()
    correct = 0
    y, c = [], []
    with torch.no_grad():
        for data, target in test_loader:
            data, target = data.cuda(), target.cuda()
            output = net(data)
            pred = output.data.max(1)[1]
            correct += pred.eq(target.data).sum().item()
    return correct / len(test_loader.dataset) * 100


def train_ours(epoch, args):
    net.train()

    loss_avg = 0.0
    train_loader_out.dataset.offset = np.random.randint(len(train_loader_in.dataset))
    for batch_idx, (in_set, out_set) in enumerate(zip(train_loader_in, train_loader_out)):
        data, target = torch.cat((in_set[0], out_set[0]), 0), in_set[1]
        data, target = data.cuda(), target.cuda()

        x, emb = net.pred_emb(data)
        l_ce = F.cross_entropy(x[:len(in_set[0])], target)
        l_oe_old = - (x[len(in_set[0]):].mean(1) - torch.logsumexp(x[len(in_set[0]):], dim=1)).mean()

        ############################################################################################################
        emb = emb/torch.norm(emb, dim=1, keepdim=True)
        a = net.fc.weight.data/torch.norm(net.fc.weight.data, dim=1, keepdim=True)
        loss_parallel = 0
        for k in range(in_set[0].shape[0]):
            loss_parallel += -(emb[:len(in_set[0])][k] @ a[target[k]])
        loss_parallel = loss_parallel/in_set[0].shape[0]
        loss_orth = torch.norm((emb[len(in_set[0]):] @ a.T), p=1, dim=1).mean()
        
        if epoch < args.stage2_start:
            loss = l_ce + 0.5*l_oe_old
        else:
            loss = l_ce + 0.5*l_oe_old + args.alpha*loss_parallel + args.beta_ours*loss_orth  
        ############################################################################################################
        optimizer.zero_grad()
        loss.backward()
        optimizer.step()

        loss_avg = loss_avg * 0.8 + float(loss) * 0.2
        # sys.stdout.write('\r epoch %2d %d/%d loss %.2f' %(epoch, batch_idx + 1, len(train_loader_in), loss_avg))
        sys.stdout.write('\r epoch %2d %d/%d parloss %.2f orthloss %.2f loss %.2f' %(epoch, batch_idx + 1, len(train_loader_in), loss_parallel, loss_orth, l_ce + 0.5*l_oe_old))
        scheduler.step()
    return
    

def train_oe(epoch, args):
    net.train()

    loss_avg = 0.0
    train_loader_out.dataset.offset = np.random.randint(len(train_loader_in.dataset))
    for batch_idx, (in_set, out_set) in enumerate(zip(train_loader_in, train_loader_out)):
        data, target = torch.cat((in_set[0], out_set[0]), 0), in_set[1]
        data, target = data.cuda(), target.cuda()

        x, emb = net.pred_emb(data)
        l_ce = F.cross_entropy(x[:len(in_set[0])], target)
        l_oe_old = - (x[len(in_set[0]):].mean(1) - torch.logsumexp(x[len(in_set[0]):], dim=1)).mean()

        loss = l_ce + 0.5*l_oe_old
        
        ############################################################################################################
        optimizer.zero_grad()
        loss.backward()
        optimizer.step()

        loss_avg = loss_avg * 0.8 + float(loss) * 0.2
        sys.stdout.write('\r epoch %2d %d/%d loss %.2f' %(epoch, batch_idx + 1, len(train_loader_in), loss_avg))
        # sys.stdout.write('\r epoch %2d %d/%d parloss %.2f orthloss %.2f loss %.2f' %(epoch, batch_idx + 1, len(train_loader_in), loss_parallel, loss_orth, l_ce + 0.5*l_oe_old))
        scheduler.step()
    return


if args.model == 'wideresnet':
    net = WideResNet(args.layers, num_classes, args.widen_factor, dropRate=args.droprate).cuda()
    if args.dataset == 'cifar10':
        model_path = './models/cifar10_wrn_pretrained_epoch_99.pt'
    else:
        model_path = './models/cifar100_wrn_pretrained_epoch_99.pt'
    net.load_state_dict(torch.load(model_path))
elif args.model == 'resnet':
    net = resnet18(10 if args.dataset == 'cifar10' else 100).cuda()
    if args.dataset == 'cifar10':
        model_path = './weights/SGD_resnet18_cifar10_labsmooth=0.1/seed_111.pt'
    else:
        model_path = './weights/cifar100_resnet18_epoch199.pt'
    net.load_state_dict(torch.load(model_path)['model'])
elif args.model == 'densenet':
    net = densenet121(num_classes=10 if args.dataset == 'cifar10' else 100).cuda()
    if args.dataset == 'cifar10':
        model_path = './weights/SGD_densenet_cifar10_labsmooth=0.1/seed_111.pt'
    else:
        model_path = './weights/SGD_densenet_cifar100_labsmooth=0.1/seed_111.pt'
    net.load_state_dict(torch.load(model_path)['model'])

# for name, param in net.named_modules():
#     print(name)
# print(fsdfds)

optimizer = torch.optim.SGD(net.parameters(), args.learning_rate, momentum=args.momentum, weight_decay=args.decay, nesterov=True)
def cosine_annealing(step, total_steps, lr_max, lr_min):
    return lr_min + (lr_max - lr_min) * 0.5 * (1 + np.cos(step / total_steps * np.pi))
scheduler = torch.optim.lr_scheduler.LambdaLR(optimizer, lr_lambda=lambda step: cosine_annealing(step, args.epochs * len(train_loader_in), 1, 1e-6 / args.learning_rate))


print('\n acc:', test())

os.makedirs('./' + file_name + '/models/', exist_ok=True)
print('score_type:', args.score_type)
print('model:', args.model)
for epoch in range(args.epochs):
    train_oe(epoch, args)
    print('\n acc:', test())
    if epoch % 10 == 9: 
        net.eval()
        in_score = get_ood_scores(test_loader, in_dist=True, score_type=args.score_type, data=args.dataset)
        metric_ll = []
        metric_ll.append(get_and_print_results(svhn_loader, in_score, score_type=args.score_type, data=args.dataset))
        metric_ll.append(get_and_print_results(lsunc_loader, in_score, score_type=args.score_type, data=args.dataset))
        metric_ll.append(get_and_print_results(isun_loader, in_score, score_type=args.score_type, data=args.dataset))
        metric_ll.append(get_and_print_results(texture_loader, in_score, score_type=args.score_type, data=args.dataset))
        metric_ll.append(get_and_print_results(places365_loader, in_score, score_type=args.score_type, data=args.dataset))
        print('\n & %.2f & %.2f & %.2f' % tuple((100 * torch.Tensor(metric_ll).mean(0)).tolist()))

    torch.save(net.state_dict(), file_name + '/models/'+ args.dataset + '_' + args.model + '_OE.pt')
    



