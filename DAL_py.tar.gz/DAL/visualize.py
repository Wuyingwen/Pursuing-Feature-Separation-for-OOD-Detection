# -*- coding: utf-8 -*-
# python visualize.py cifar10 --check _vanilla --check_2 _train --check_3 _auxiliary
# python visualize.py cifar100 --check _vanilla --check_2 _train --check_3 _auxiliary
# python visualize.py cifar100 --check _vanilla --check_2 _test --check_3 _isun

# python visualize.py cifar100 --check _vanilla --check_2 _train --check_3 _lsun

import numpy as np
import sys
import argparse
import torch
import torch.nn as nn
import torch.backends.cudnn as cudnn
import torchvision.transforms as trn
import torchvision.datasets as dset
import torch.nn.functional as F
from models.wrn import WideResNet

import utils.svhn_loader as svhn
from utils.display_results import get_measures, print_measures
from utils.tinyimages_80mn_loader import TinyImages
import torchvision
from sklearn.manifold import TSNE
import os
import sklearn
import matplotlib.pyplot as plt
import seaborn as sns

parser = argparse.ArgumentParser(description='DAL training procedure on the CIFAR benchmark',
                                 formatter_class=argparse.ArgumentDefaultsHelpFormatter)
parser.add_argument('dataset', type=str, choices=['cifar10', 'cifar100'],
                    help='Choose between CIFAR-10, CIFAR-100.')

# Optimization options
parser.add_argument('--epochs', '-e', type=int, default=50, help='Number of epochs to train.')
parser.add_argument('--learning_rate', '-lr', type=float, default=0.01, help='The initial learning rate.')
parser.add_argument('--batch_size', '-b', type=int, default=128, help='Batch size.')
parser.add_argument('--oe_batch_size', type=int, default=256, help='Batch size.')
parser.add_argument('--test_bs', type=int, default=200)
parser.add_argument('--momentum', type=float, default=0.9, help='Momentum.')
parser.add_argument('--decay', '-d', type=float, default=0.0005, help='Weight decay (L2 penalty).')
# WRN Architecture
parser.add_argument('--layers', default=40, type=int, help='total number of layers')
parser.add_argument('--widen-factor', default=2, type=int, help='widen factor')
parser.add_argument('--droprate', default=0.3, type=float, help='dropout probability')
# DAL hyper parameters
parser.add_argument('--gamma', default=1, type=float)
parser.add_argument('--beta',  default=0.5, type=float)
parser.add_argument('--rho',   default=0.01, type=float)
parser.add_argument('--strength', default=0.01, type=float)
parser.add_argument('--warmup', type=int, default=0)
parser.add_argument('--iter', default=10, type=int)
# Others
parser.add_argument('--out_as_pos', action='store_true', help='OE define OOD data as positive.')
parser.add_argument('--seed', type=int, default=1, help='seed for np(tinyimages80M sampling); 1|2|8|100|107')
#########
parser.add_argument('--check', type=str, default='_vanilla', help='_vanilla, _oe, _dal, _ours')
parser.add_argument('--check_2', type=str, default='_test', help='_train')
parser.add_argument('--check_3', type=str, default='_svhn', help='_auxiliary')

args = parser.parse_args()
torch.manual_seed(1)
np.random.seed(args.seed)
torch.cuda.manual_seed(1)

print(args.gamma, args.beta, args.rho)

cudnn.benchmark = True  # fire on all cylinders


# mean and standard deviation of channels of CIFAR-10 images
mean = [x / 255 for x in [125.3, 123.0, 113.9]]
std = [x / 255 for x in [63.0, 62.1, 66.7]]

train_transform = trn.Compose([trn.RandomHorizontalFlip(), trn.RandomCrop(32, padding=4),
                                trn.ToTensor(), trn.Normalize(mean, std)])
test_transform = trn.Compose([trn.ToTensor(), trn.Normalize(mean, std)])
test_transform_imagenet = trn.Compose([trn.Resize((32,32)), trn.ToTensor(), trn.Normalize(mean, std)])

if args.dataset == 'cifar10':
    train_data_in = dset.CIFAR10('../data', train=True, transform=test_transform)
    test_data = dset.CIFAR10('../data', train=False, transform=test_transform)
    cifar_data = dset.CIFAR100('../data', train=False, transform=test_transform)
    imagenet_data = torchvision.datasets.ImageFolder('/home/datasets/ILSVRC2012/val', test_transform_imagenet)
    num_classes = 10
else:
    # train_data_in = dset.CIFAR100('../data', train=True, transform=train_transform)
    train_data_in = dset.CIFAR100('../data', train=True, transform=test_transform)
    test_data = dset.CIFAR100('../data', train=False, transform=test_transform)
    cifar_data = dset.CIFAR10('../data', train=False, transform=test_transform)
    num_classes = 100

# ood_data = TinyImages(transform=trn.Compose([trn.ToTensor(), trn.ToPILImage(), trn.RandomCrop(32, padding=4), trn.RandomHorizontalFlip(), trn.ToTensor(), trn.Normalize(mean, std)]), exclude_cifar = True)
# transform_for_ood = trn.Compose([trn.ToTensor(), trn.ToPILImage(), trn.RandomCrop(32, padding=4), trn.RandomHorizontalFlip(), trn.ToTensor(), trn.Normalize(mean, std)])
transform_for_ood = trn.Compose([trn.ToTensor(), trn.Normalize(mean, std)])
ood_x = np.load('../data/300K_random_images.npy')
class MyDataset(torch.utils.data.Dataset):
    def __init__(self, data, label, transform=trn.Compose([trn.ToTensor()])):

        self.data = data
        self.label = torch.from_numpy(label)
        self.transform = transform
    def __getitem__(self, index):
        data = self.data[index]
        label = self.label[index]

        data = self.transform(data)

        return data, label 

    def __len__(self):
        return self.data.shape[0]
ood_data = MyDataset(ood_x, np.zeros(ood_x.shape[0]), transform_for_ood)


train_loader_in = torch.utils.data.DataLoader(train_data_in, batch_size=args.batch_size, shuffle=False, num_workers=4, pin_memory=False)
train_loader_out = torch.utils.data.DataLoader(ood_data, batch_size=args.oe_batch_size, shuffle=False, num_workers=4, pin_memory=True)
test_loader = torch.utils.data.DataLoader(test_data, batch_size=args.batch_size, shuffle=False, num_workers=4, pin_memory=False)

texture_data = dset.ImageFolder(root="../data/ood_data/dtd/images", transform=trn.Compose([trn.Resize(32), trn.CenterCrop(32), trn.ToTensor(), trn.Normalize(mean, std)]))
svhn_data = svhn.SVHN(root='../data/ood_data/svhn/', split="test",transform=trn.Compose( [trn.ToTensor(), trn.Normalize(mean, std)]), download=False)
places365_data = dset.ImageFolder(root="../data/ood_data/places365", transform=trn.Compose([trn.Resize(32), trn.CenterCrop(32), trn.ToTensor(), trn.Normalize(mean, std)]))
lsunc_data = dset.ImageFolder(root="../data/ood_data/LSUN", transform=trn.Compose([trn.Resize(32), trn.ToTensor(), trn.Normalize(mean, std)]))

lsunfix_data = dset.ImageFolder(root="../data/ood_data/LSUN", transform=trn.Compose([trn.ToTensor(), trn.Normalize(mean, std)]))

isun_data = dset.ImageFolder(root="../data/ood_data/iSUN",transform=trn.Compose([trn.ToTensor(), trn.Normalize(mean, std)]))

texture_loader = torch.utils.data.DataLoader(texture_data, batch_size=args.test_bs, shuffle=False, num_workers=4, pin_memory=False)
svhn_loader = torch.utils.data.DataLoader(svhn_data, batch_size=args.test_bs, shuffle=True, num_workers=4, pin_memory=False)
places365_loader = torch.utils.data.DataLoader(places365_data, batch_size=args.test_bs, shuffle=False, num_workers=4, pin_memory=False)
lsunc_loader = torch.utils.data.DataLoader(lsunc_data, batch_size=args.test_bs, shuffle=False, num_workers=4, pin_memory=False)
lsunfix_loader = torch.utils.data.DataLoader(lsunfix_data, batch_size=args.test_bs, shuffle=False, num_workers=4, pin_memory=False)
isun_loader = torch.utils.data.DataLoader(isun_data, batch_size=args.test_bs, shuffle=False, num_workers=4, pin_memory=False)
cifar_loader = torch.utils.data.DataLoader(cifar_data, batch_size=args.test_bs, shuffle=False, num_workers=4, pin_memory=False)
# imagenet_loader = torch.utils.data.DataLoader(imagenet_data, batch_size=args.test_bs, shuffle=True, num_workers=4, pin_memory=False)
ood_num_examples = len(test_data) // 5
expected_ap = ood_num_examples / (ood_num_examples + len(test_data))
concat = lambda x: np.concatenate(x, axis=0)
to_np = lambda x: x.data.cpu().numpy()


def get_ood_scores(loader, score_type='msp', in_dist=False):
    _score = []
    net.eval()
    with torch.no_grad():
        for batch_idx, (data, target) in enumerate(loader):
            if batch_idx >= ood_num_examples // args.test_bs and in_dist is False:
                break
            data, target = data.cuda(), target.cuda()
            output = net(data)
            if score_type == 'msp':
                smax = to_np(F.softmax(output, dim=1))
                _score.append(-np.max(smax, axis=1))
    if in_dist:
        return concat(_score).copy() # , concat(_right_score).copy(), concat(_wrong_score).copy()
    else:
        return concat(_score)[:ood_num_examples].copy()

def get_and_print_results(ood_loader, in_score, score_type='msp', num_to_avg=1):
    net.eval()
    aurocs, auprs, fprs = [], [], []
    for _ in range(num_to_avg):
        out_score = get_ood_scores(ood_loader, score_type)
        print(out_score.shape)
        if args.out_as_pos: # OE's defines out samples as positive
            measures = get_measures(out_score, in_score)
        else:
            measures = get_measures(-in_score, -out_score)
        aurocs.append(measures[0]); auprs.append(measures[1]); fprs.append(measures[2])
    auroc = np.mean(aurocs); aupr = np.mean(auprs); fpr = np.mean(fprs)
    print_measures(auroc, aupr, fpr, '')
    return fpr, auroc, aupr

def train(epoch, gamma):

    net.train()

    loss_avg = 0.0
    train_loader_out.dataset.offset = np.random.randint(len(train_loader_in.dataset))
    for batch_idx, (in_set, out_set) in enumerate(zip(train_loader_in, train_loader_out)):

        data, target = torch.cat((in_set[0], out_set[0]), 0), in_set[1]
        data, target = data.cuda(), target.cuda()

        x, emb = net.pred_emb(data)
        l_ce = F.cross_entropy(x[:len(in_set[0])], target)
        l_oe_old = - (x[len(in_set[0]):].mean(1) - torch.logsumexp(x[len(in_set[0]):], dim=1)).mean()

        # smax_oe = F.log_softmax(x[len(in_set[0]):] - torch.max(x[len(in_set[0]):], dim=1, keepdim=True)[0], dim=1)
        # oe_loss = -1 * smax_oe.mean()  # minimizing cross entropy
        # print(l_oe_old, oe_loss)
        # print(fdsfs)

        emb_oe = emb[len(in_set[0]):].detach()
        emb_bias = torch.rand_like(emb_oe) * 0.0001

        for _ in range(args.iter):
            emb_bias.requires_grad_()

            x_aug = net.fc(emb_bias + emb_oe)
            l_sur = - (x_aug.mean(1) - torch.logsumexp(x_aug, dim=1)).mean()
            r_sur = (emb_bias.abs()).mean(-1).mean()
            l_sur = l_sur - r_sur * gamma
            grads = torch.autograd.grad(l_sur, [emb_bias])[0]
            grads /= (grads ** 2).sum(-1).sqrt().unsqueeze(1)
            
            emb_bias = emb_bias.detach() + args.strength * grads.detach() # + torch.randn_like(grads.detach()) * 0.000001
            optimizer.zero_grad()
        
        gamma -= args.beta * (args.rho - r_sur.detach())
        gamma = gamma.clamp(min=0.0, max=args.gamma)
        if epoch >= args.warmup:
            x_oe = net.fc(emb[len(in_set[0]):] + emb_bias)
        else:    
            x_oe = net.fc(emb[len(in_set[0]):])
        
        l_oe = - (x_oe.mean(1) - torch.logsumexp(x_oe, dim=1)).mean()
        loss = l_ce + .5 * l_oe
        # loss = l_ce + l_oe

        # loss = l_ce + .5 * l_oe_old
        # loss = l_ce + l_oe_old
        # loss = l_ce
    
        optimizer.zero_grad()
        loss.backward()
        optimizer.step()

        loss_avg = loss_avg * 0.8 + float(loss) * 0.2
        sys.stdout.write('\r epoch %2d %d/%d loss %.2f' %(epoch, batch_idx + 1, len(train_loader_in), loss_avg))
        scheduler.step()
    return gamma

def test_loss():
    net.eval()
    loss_avg = 0.0
    train_loader_out.dataset.offset = np.random.randint(len(train_loader_in.dataset))

    for batch_idx, (in_set, out_set) in enumerate(zip(train_loader_in, train_loader_out)):
        data, target = torch.cat((in_set[0], out_set[0]), 0), in_set[1]
        data, target = data.cuda(), target.cuda()

        x = net(data)
        l_ce = F.cross_entropy(x[:len(in_set[0])], target)
        l_oe_old = - (x[len(in_set[0]):].mean(1) - torch.logsumexp(x[len(in_set[0]):], dim=1)).mean()
        loss = l_ce + .5 * l_oe_old
        
        loss_avg = loss_avg * 0.8 + float(loss) * 0.2
        sys.stdout.write('\r %d/%d loss %.2f' %(batch_idx + 1, len(train_loader_in), loss_avg))

    return

def test():
    net.eval()
    correct = 0
    y, c = [], []
    with torch.no_grad():
        for data, target in test_loader:
            data, target = data.cuda(), target.cuda()
            output = net(data)
            pred = output.data.max(1)[1]
            correct += pred.eq(target.data).sum().item()
    return correct / len(test_loader.dataset) * 100


net = WideResNet(args.layers, num_classes, args.widen_factor, dropRate=args.droprate).cuda()
if args.dataset == 'cifar10':
    model_path = '../model/cifar10_wrn_pretrained_epoch_99.pt'
else:
    model_path = '../model/cifar100_wrn_pretrained_epoch_99.pt'
optimizer = torch.optim.SGD(net.parameters(), args.learning_rate, momentum=args.momentum, weight_decay=args.decay, nesterov=True)
scheduler = torch.optim.lr_scheduler.CosineAnnealingLR(optimizer, T_max=args.epochs)

# for name,p in net.named_parameters():
#     print(name, p.shape)
# for n, m in net.named_modules():
#     print(n)

# print(fdsfsd)
##################################################################
if args.check == '_vanilla':
    net.load_state_dict(torch.load('./models/'+ args.dataset + '_baseline_vanilla.pt')) # vanilla
elif args.check == '_oe':
    net.load_state_dict(torch.load('./models/'+ args.dataset + '_baseline_oe_v21.pt')) # OE
elif args.check == '_dal':
    net.load_state_dict(torch.load('./models/'+ args.dataset + '_baseline_aug_v22.pt')) # DAL
elif args.check == '_ours':
    net.load_state_dict(torch.load('./models/'+ args.dataset + '_bz' + str(args.oe_batch_size) + '_feature_po_2_v11_21.pt')) # Ours
net.eval()
# print('\n acc:', test())


# -------------------- 第一步：定义接收feature的函数 ---------------------- #
# 这里定义了一个类，类有一个接收feature的函数hook_fun。定义类是为了方便提取多个中间层。
class HookTool: 
    def __init__(self):
        self.fea = None 

    def hook_fun(self, module, fea_in, fea_out):
        self.fea = fea_out

# ---------- 第二步：注册hook，告诉模型我将在哪些层提取feature,比如提取'fc'后的feature，即output -------- #
def get_feas_by_hook(model, extract_module=['avg_pool']):
    fea_hooks = []
    for n, m in model.named_modules():
        if n in extract_module:
            cur_hook = HookTool()
            m.register_forward_hook(cur_hook.hook_fun)
            fea_hooks.append(cur_hook)
            
    return fea_hooks

def obtain_feature_loader(model, dataloader, save_path, save_name, args, check):
    if not os.path.exists(save_path + save_name + '_foward_feature'+check+'.npy'):
        forward_feature = []
        label = []
        total = 0
        for i, batch in enumerate(dataloader):
            if total > 50000:
                break
            
            inputs, targets = batch   
            inputs = inputs.cuda()
            targets = targets.cuda()

            total = total + targets.shape[0]
            fea_hooks = get_feas_by_hook(model, extract_module=['avg_pool'])

            outputs = model(inputs)
            
            features = fea_hooks[0].fea.squeeze()
            
            forward_feature.append(features.detach().cpu())
            label.append(targets.detach().cpu())

        forward_feature = torch.cat(forward_feature, 0)
        label = torch.cat(label, dim=0)
        forward_feature = forward_feature.numpy()
        label = label.numpy()
        print(forward_feature.shape, label.shape)
        np.save(save_path + save_name + '_foward_feature'+check+'.npy', forward_feature)
        np.save(save_path + save_name + '_label'+check+'.npy', label)
    else:
        forward_feature = np.load(save_path + save_name + '_foward_feature'+check+'.npy')
        label = np.load(save_path + save_name + '_label'+check+'.npy')
        print(forward_feature.shape, label.shape)
    
    dataset = MyDataset(forward_feature, label)
    feature_dataloader = torch.utils.data.DataLoader(dataset, batch_size=args.batch_size, shuffle=False, num_workers=4)

    return forward_feature, label, feature_dataloader


plt.style.use('seaborn')
# plt.style.use('ggplot')
# plt.rcParams.update({'font.size': 14})
#### 坐标轴刻度
plt.rcParams['xtick.labelsize']=20
plt.rcParams['ytick.labelsize']=20
#### 坐标轴字体
plt.rcParams['axes.labelsize'] = 20
#### legend
plt.rcParams['legend.fontsize'] = 20
#### figure大小
fontsize = 20
plt.rcParams['figure.figsize'] = (8, 6)


file_name=os.path.basename(__file__).split(".")[0]
# save_path = file_name + '/' 
# save_path = file_name + '/2024_05_16/'
# save_path = file_name + '/2024_05_18/'
# save_path = file_name + '/2024_05_20/'
save_path = file_name + '/2024_05_21/'
os.makedirs(save_path, exist_ok=True)

############################################################################
# args.dataset = 'cifar100'
if args.dataset == 'cifar100':
    num_classes = 100
else:
    num_classes = 10

# check = ''
check = args.check
check_3 = args.check_3
save_name = args.dataset + '_test' + check
test_forward_feature, test_label, test_feature_dataloader = obtain_feature_loader(net, test_loader, save_path, save_name, args, check)

save_name = args.dataset + '_train' + check
train_forward_feature, train_label, train_feature_dataloader = obtain_feature_loader(net, train_loader_in, save_path, save_name, args, check)

# save_name = args.dataset + check_3 + check
# if check_3 == '_svhn':
#     ood_loader = svhn_loader
# elif check_3 == '_isun':
#     ood_loader = isun_loader
# elif check_3 == '_lsun':
#     ood_loader = lsunc_loader
# else:
#     ood_loader = train_loader_out
save_name = args.dataset + '_lsun' + check
ood_loader = lsunc_loader
svhn_forward_feature, svhn_label, svhn_feature_dataloader = obtain_feature_loader(net, ood_loader, save_path, save_name, args, check)

save_name = args.dataset + '_auxiliary' + check
auxiliary_forward_feature, auxiliary_label, auxiliary_feature_dataloader = obtain_feature_loader(net, train_loader_out, save_path, save_name, args, check)

# #############################################################################################
weight_reduction_matrix = net.fc.weight.data.cpu().detach()
print(weight_reduction_matrix.shape)
weight_reduction_matrix = weight_reduction_matrix/torch.norm(weight_reduction_matrix, dim=1, keepdim=True)

def cosin(a, b):
    cos = (a.unsqueeze(0) @ b.unsqueeze(1))/(torch.norm(a)*torch.norm(b))
    return cos

class1 = 2
class2 = 4
# class3 = 6
# for i in range(10):
#     for j in range(10):
#         print(i, j, cosin(weight_reduction_matrix[i], weight_reduction_matrix[j]))

index = [class1, class2]#, class3]
reduce_matrix = weight_reduction_matrix[index]#.numpy()
print(cosin(reduce_matrix[0], reduce_matrix[1]))

def qr_alter(omiga):
    for i in range(omiga.shape[0]):
        omiga[i] = omiga[i] - torch.sum(torch.mm(omiga[i].unsqueeze(0), omiga[0:i].T).T*omiga[0:i], dim=0)
        omiga[i] = omiga[i]/torch.norm(omiga[i])
    # print(omiga, omiga.shape)
    return omiga

# reduce_matrix = qr_alter(reduce_matrix)
# print(cosin(reduce_matrix[0], reduce_matrix[1]))
# reduce_matrix = reduce_matrix.numpy()

# pca = sklearn.decomposition.PCA(n_components=1, copy=True, whiten=False)   # 10 dimension occupy 95.5% components
# pca.fit(svhn_forward_feature)
# # low_test_forward_feature = pca.fit_transform(test_forward_feature)
# pca_reduction_matrix = pca.components_
# reduce_matrix = torch.cat([reduce_matrix, torch.from_numpy(pca_reduction_matrix)], 0)
# # reduce_matrix = qr_alter(reduce_matrix)
# # print(cosin(reduce_matrix[1], reduce_matrix[2]))
# reduce_matrix = reduce_matrix.numpy()
# print(reduce_matrix.shape)

if not os.path.exists(save_path + args.dataset + '_train_label_indices.npy'):
    indices = [[] for _ in range(num_classes)]
    # 遍历训练集
    for i in range(len(train_data_in)):
        img, label = train_data_in[i]
        indices[label].append(i)
        # print(indices[label])
    indices = np.array(indices)   
    print('indices: ', indices.shape)
    np.save(save_path + args.dataset + '_train_label_indices.npy', indices)


if not os.path.exists(save_path + args.dataset + '_test_label_indices.npy'):
    indices = [[] for _ in range(num_classes)]
    # 遍历训练集
    for i in range(len(test_data)):
        img, label = test_data[i]
        indices[label].append(i)
        # print(indices[label])
    indices = np.array(indices)   
    print('indices: ', indices.shape)
    np.save(save_path + args.dataset + '_test_label_indices.npy', indices)

check_2 = args.check_2
# check_2 = ''
# check_2 = '_train'
indices = np.load(save_path + args.dataset + check_2 + '_label_indices.npy', allow_pickle=True)
# low_test_forward_feature_0 = test_forward_feature[indices[class1]] @ reduce_matrix.T
# low_test_forward_feature_9 = test_forward_feature[indices[class2]] @ reduce_matrix.T
if check_2 =='_train':
    test_forward_feature = train_forward_feature

# ts = TSNE(n_components=2, init='pca', random_state=0)

num1 = len(indices[class1])
if num1>1000:
    num1 = 1000
feat = np.append(test_forward_feature[indices[class1][0:num1]], test_forward_feature[indices[class2][0:num1]], axis=0)

# # feat = np.append(feat, test_forward_feature[indices[class3]], axis=0)
if check_3 == '_auxiliary':
    feat = np.append(feat, auxiliary_forward_feature[0:num1], axis=0)
else:
    feat = np.append(feat, svhn_forward_feature[0:num1], axis=0)
# print(feat.shape)
# x_ts = ts.fit_transform(feat)

x_ts = feat @ reduce_matrix.numpy().T
print('num1: ', num1)
print('x_ts: ', x_ts.shape)

def scatter_plot(x, y, save_path, save_name):
    plt.clf()

    fig = plt.figure()
    ax = plt.subplot(111)
    fig.add_axes(ax)

    plt.scatter(x[:,0], x[:,1], c='#4472C4', alpha=0.5, marker='.', label='Class-1')
    plt.scatter(y[:,0], y[:,1], c='#D8722D', alpha=0.5, marker='.', label='Class-2')
    # plt.scatter(z[:,0], z[:,1], c='#FA7F6F', alpha=1, marker='.', label='Outlier')

    # plt.arrow(0,0,8,0, width=0.1, fc='#4472C4', ec='#4472C4', alpha = 1)
    # plt.arrow(0,0,0,8, width=0.1, fc='#D8722D', ec='#D8722D', alpha = 1)
    # plt.text(8.1, 0.2, r"$w_1$", fontsize=20, c='#4472C4', fontweight='heavy')
    # plt.text(-0.7, 8.3, r"$w_2$", fontsize=20, c='#D8722D', fontweight='heavy')
    
    plt.legend()
    plt.tight_layout()
    plt.savefig(save_path + save_name + '.png', dpi=800)
    return

# scatter_plot(low_test_forward_feature_0, low_test_forward_feature_9, save_path, str(class1) + '+' + str(class2))
# scatter_plot(low_test_forward_feature_0, low_test_forward_feature_9, save_path, str(class1) + '+' + str(class2) + '_train')

from mpl_toolkits.mplot3d import Axes3D
def scatter_plot_2(x, y, z, save_path, save_name):
    plt.clf()

    fig = plt.figure()
    ax = plt.subplot(111)
    fig.add_axes(ax)
    class1 = plt.scatter(x[:,0], x[:,1], c='#4472C4', alpha=0.5, marker='.', label='Class-1')
    class2 = plt.scatter(y[:,0], y[:,1], c='#D8722D', alpha=0.5, marker='.', label='Class-2')
    outlier = plt.scatter(z[:,0], z[:,1], c='#A9D18E', alpha=0.8, marker='.', label='Outlier')

    # plt.arrow(0,0,8,0, width=0.1, fc='#4472C4', ec='#4472C4', alpha = 1)
    # plt.arrow(0,0,0,8, width=0.1, fc='#D8722D', ec='#D8722D', alpha = 1)
    # plt.text(8.1, 0.2, r"$w_1$", fontsize=20, c='#4472C4', fontweight='heavy')
    # plt.text(-0.7, 8.3, r"$w_2$", fontsize=20, c='#D8722D', fontweight='heavy')

    # class1_legend = plt.Line2D([], [], marker='o', markersize=10, color='#4472C4', label='Class-1')
    # class2_legend = plt.Line2D([], [], marker='o', markersize=10, color='#D8722D', label='Class-2')
    # outlier_legend = plt.Line2D([], [], marker='o', markersize=10, color='#A9D18E', label='Outlier')
    # handles=[class1, class2, outlier, class1_legend, class2_legend, outlier_legend]

    plt.show()
    plt.legend()
    plt.tight_layout()
    plt.savefig(save_path + save_name + '.png', dpi=800)
    plt.savefig(save_path + save_name + '.pdf', format='pdf', bbox_inches='tight')
    return

# np.save('x_ts' + check + '.npy', x_ts)

# scatter_plot_2(x_ts[0:1000], x_ts[1000:2000], x_ts[2000:3000], save_path, str(class1) + '+' + str(class2) + '+svhn_tsne' + check)
# scatter_plot_2(x_ts[0:1000], x_ts[1000:2000], x_ts[2000:3000], x_ts[3000:4000], save_path, str(class1) + '+' + str(class2) + '+svhn_3D_weight+svhnPCA_project' + check)
# scatter_plot_2(x_ts[0:1000], x_ts[1000:2000], x_ts[2000:3000], save_path, str(class1) + '+' + str(class2) + '+svhn_tsne' + check)
# scatter_plot_2(x_ts[0:num1], x_ts[num1:2*num1], x_ts[2*num1:3*num1], save_path, args.dataset + '_' + str(class1) + '+' + str(class2) + check_3 + '_project' + check + check_2)
# print(fsdfsd)


from mpl_toolkits.mplot3d import Axes3D
def scatter_plot_3(x, y, z, save_path, save_name):
    plt.clf()

    fig = plt.figure(figsize=(8, 6))
    ax1 = fig.add_subplot(111, projection='3d')
    class1 = ax1.scatter3D(x[:,0], x[:,1], x[:,2], c='#4472C4', alpha=0.5, marker='.', label='Class-1')
    class2 = ax1.scatter3D(y[:,0], y[:,1], y[:,2], c='#D8722D', alpha=0.5, marker='.', label='Class-2')
    outlier = ax1.scatter3D(z[:,0], z[:,1], z[:,2], c='#A9D18E', alpha=0.8, marker='.', label='Outlier')
    
    # class1_legend = plt.Line2D([], [], marker='o', markersize=10, color='#4472C4', label='Class-1')
    # class2_legend = plt.Line2D([], [], marker='o', markersize=10, color='#D8722D', label='Class-2')
    # outlier_legend = plt.Line2D([], [], marker='o', markersize=10, color='#A9D18E', label='Outlier')
    # handles=[class1, class2, outlier, class1_legend, class2_legend, outlier_legend]

    fig.legend(loc='upper left', bbox_to_anchor=(0.53, 0.80))
    # leg.set_zorder(8)
    # ax1.legend(loc = 'upper right', bbox_to_anchor=(0.5, 0.5, 1, 1))
    # fig.tight_layout()
    plt.show()
    plt.savefig(save_path + save_name + '.png', dpi=800, bbox_inches='tight')
    plt.savefig(save_path + save_name + '.pdf', format='pdf', bbox_inches='tight')
    return

def scatter_plot_3_selected(x, y, z, save_path, save_name):
    plt.clf()

    x_selected = []
    for x_i in x:
        if x_i[2]<3:
            x_selected.append(x_i)
    x_selected = np.array(x_selected)
    print('x_selected: ', x_selected.shape)

    y_selected = []
    for y_i in y:
        if y_i[2]<5:
            y_selected.append(y_i)
    y_selected = np.array(y_selected)
    print('y_selected: ', y_selected.shape)

    x = x_selected
    y = y_selected

    fig = plt.figure(figsize=(8, 6))
    ax1 = fig.add_subplot(111, projection='3d')
    class1 = ax1.scatter3D(x[:,0], x[:,1], x[:,2], c='#4472C4', alpha=0.5, marker='.', label='Class-1')
    class2 = ax1.scatter3D(y[:,0], y[:,1], y[:,2], c='#D8722D', alpha=0.5, marker='.', label='Class-2')
    outlier = ax1.scatter3D(z[:,0], z[:,1], z[:,2], c='#A9D18E', alpha=0.8, marker='.', label='Outlier')

    fig.legend(loc='upper left', bbox_to_anchor=(0.53, 0.80))
    plt.show()
    plt.savefig(save_path + save_name + '.png', dpi=800, bbox_inches='tight')
    plt.savefig(save_path + save_name + '.pdf', format='pdf', bbox_inches='tight')
    return x,y

if check_3 == '_auxiliary':
    ood_forward_feature = auxiliary_forward_feature
    print('using auxiliary OOD to calculate the z-axis')
else:
    ood_forward_feature = svhn_forward_feature
pca = sklearn.decomposition.PCA(n_components=1, copy=True, whiten=False)   # 10 dimension occupy 95.5% components
pca.fit(ood_forward_feature)
pca_reduction_matrix = pca.components_
reduce_matrix = torch.cat([reduce_matrix, torch.from_numpy(pca_reduction_matrix)], 0)
print(reduce_matrix.shape, pca.explained_variance_ratio_)
# reduce_matrix = qr_alter(reduce_matrix)
x_ts = feat @ reduce_matrix.numpy().T
# scatter_plot_3(x_ts[0:num1], x_ts[num1:2*num1], x_ts[2*num1:3*num1], save_path, args.dataset + '_' + str(class1) + '+' + str(class2) + check_3 + '_project' + check + check_2 + '_3D')
x, y = scatter_plot_3_selected(x_ts[0:num1], x_ts[num1:2*num1], x_ts[2*num1:3*num1], save_path, args.dataset + '_' + str(class1) + '+' + str(class2) + check_3 + '_project' + check + check_2 + '_3D_selected')

# plt.style.use('seaborn')
# plt.rcParams['legend.fontsize'] = 20
scatter_plot_2(x, y, x_ts[2*num1:3*num1], save_path, args.dataset + '_' + str(class1) + '+' + str(class2) + check_3 + '_project' + check + check_2)

pca.fit(auxiliary_forward_feature)
pca_reduction_matrix_2 = pca.components_
print(pca.explained_variance_ratio_)
print(cosin(torch.from_numpy(pca_reduction_matrix_2.flatten()), torch.from_numpy(pca_reduction_matrix.flatten())))

print(fdsfs)
########## 同时有 auxiliary OOD data 和 lsun OOD data 的图
def scatter_plot_4(x, y, z, w, save_path, save_name):
    plt.clf()

    fig = plt.figure()
    ax1 = plt.axes(projection='3d')
    class1 = ax1.scatter3D(x[:,0], x[:,1], x[:,2], c='#4472C4', alpha=0.5, marker='.', label='Class-1')
    class2 = ax1.scatter3D(y[:,0], y[:,1], y[:,2], c='#D8722D', alpha=0.5, marker='.', label='Class-2')
    outlier = ax1.scatter3D(z[:,0], z[:,1], z[:,2], c='#A9D18E', alpha=0.8, marker='.', label='Train Outlier')
    outlier_test = ax1.scatter3D(w[:,0], w[:,1], w[:,2], c='crimson', alpha=0.5, marker='.', label='Test Outlier')

    fig.legend(loc='upper left', bbox_to_anchor=(0.53, 0.9))
    # leg.set_zorder(8)
    # ax1.legend(loc = 'upper right', bbox_to_anchor=(0.5, 0.5, 1, 1))
    plt.tight_layout()
    plt.show()
    plt.savefig(save_path + save_name + '.png', dpi=800)
    plt.savefig(save_path + save_name + '.pdf', format='pdf', bbox_inches='tight')
    return

def scatter_plot_5(x, y, z, w, save_path, save_name):
    plt.clf()

    fig = plt.figure()
    ax = plt.subplot(111)
    fig.add_axes(ax)
    class1 = plt.scatter(x[:,0], x[:,1], c='#4472C4', alpha=0.5, marker='.', label='Class-1')
    class2 = plt.scatter(y[:,0], y[:,1], c='#D8722D', alpha=0.5, marker='.', label='Class-2')
    outlier = plt.scatter(z[:,0], z[:,1], c='#A9D18E', alpha=0.8, marker='.', label='Train Outlier')
    outlier_test = plt.scatter(w[:,0], w[:,1], c='crimson', alpha=0.5, marker='.', label='Test Outlier')

    plt.show()
    plt.legend()
    plt.tight_layout()
    plt.savefig(save_path + save_name + '.png', dpi=800)
    plt.savefig(save_path + save_name + '.pdf', format='pdf', bbox_inches='tight')
    return

if check_3 == '_auxiliary':
    feat = np.append(feat, svhn_forward_feature[0:num1], axis=0)
    x_ts = feat @ reduce_matrix.numpy().T
    print(x_ts.shape)
    scatter_plot_4(x_ts[0:num1], x_ts[num1:2*num1], x_ts[2*num1:3*num1], x_ts[3*num1:4*num1], save_path, args.dataset + '_' + str(class1) + '+' + str(class2) + check_3 + '_project' + check + check_2 + '_3D_2')
    scatter_plot_5(x_ts[0:num1], x_ts[num1:2*num1], x_ts[2*num1:3*num1], x_ts[3*num1:4*num1], save_path, args.dataset + '_' + str(class1) + '+' + str(class2) + check_3 + '_project' + check + check_2 + '_2')
else:
    feat = np.append(feat, auxiliary_forward_feature[0:num1], axis=0)
    x_ts = feat @ reduce_matrix.numpy().T
    print(x_ts.shape)
    scatter_plot_4(x_ts[0:num1], x_ts[num1:2*num1], x_ts[3*num1:4*num1], x_ts[2*num1:3*num1], save_path, args.dataset + '_' + str(class1) + '+' + str(class2) + check_3 + '_project' + check + check_2 + '_3D_2')
    scatter_plot_5(x_ts[0:num1], x_ts[num1:2*num1], x_ts[3*num1:4*num1], x_ts[2*num1:3*num1], save_path, args.dataset + '_' + str(class1) + '+' + str(class2) + check_3 + '_project' + check + check_2 + '_2')


print(fdsfs)
#############################################################################################
weight_reduction_matrix = net.fc.weight.data.cpu().detach()
# print(weight_reduction_matrix.shape)
# weight_reduction_matrix = weight_reduction_matrix/torch.norm(weight_reduction_matrix, dim=1, keepdim=True)
# print(weight_reduction_matrix[0])
# print(weight_reduction_matrix[9])
# print(weight_reduction_matrix.shape)
# print(fdsfds)
def qr_alter(omiga):
    for i in range(omiga.shape[0]):
        omiga[i] = omiga[i] - torch.sum(torch.mm(omiga[i].unsqueeze(0), omiga[0:i].T).T*omiga[0:i], dim=0)
        omiga[i] = omiga[i]/torch.norm(omiga[i])
    # print(omiga, omiga.shape)
    return omiga

weight_reduction_matrix = qr_alter(weight_reduction_matrix)

test_forward_feature = train_forward_feature


# print(weight_reduction_matrix[0])
# print(weight_reduction_matrix[9])
# print(weight_reduction_matrix.shape)
# print(fdsfds)

# args.dataset = 'cifar10'
# num_classes = 100
pca = sklearn.decomposition.PCA(n_components=num_classes, copy=True, whiten=False)   # 10 dimension occupy 95.5% components
pca.fit(test_forward_feature)
# low_test_forward_feature = pca.fit_transform(test_forward_feature)
pca_reduction_matrix = pca.components_
# cifar10_ratio = pca.explained_variance_ratio_
# print(pca_reduction_matrix.shape, cifar10_ratio)

# weight_reduction_matrix = weight_reduction_matrix.numpy()
# pca_reduction_matrix = weight_reduction_matrix

# print('low_test_forward_feature: ', low_test_forward_feature.shape)

# rank = np.linalg.matrix_rank(pca_reduction_matrix)
# print("pca_reduction_matrix:", rank)

# rank = np.linalg.matrix_rank(weight_reduction_matrix)
# print("weight_reduction_matrix:", rank)

# a = np.append(pca_reduction_matrix, weight_reduction_matrix, axis=0)
# print(a.shape)
# rank = np.linalg.matrix_rank(a)
# print("a:", rank)

# save_name = args.dataset + '_test'
# for i in range(1, num_classes):
#     cifar10_ratio[i] = cifar10_ratio[i] + cifar10_ratio[i-1]
# cifar10_ratio = np.insert(cifar10_ratio, 0, 0)

# weight_reduction_matrix = net.fc.weight.data.cpu().detach().numpy()

# def qr_alter(omiga):
#     for i in range(omiga.shape[1]):
#         omiga[:,i] = omiga[:,i] - torch.sum(torch.mm(omiga[:,i].unsqueeze(0), omiga[:,0:i])*omiga[:,0:i], dim=1)
#         omiga[:,i] = omiga[:,i]/torch.norm(omiga[:,i])
#     # print(omiga, omiga.shape)
#     return omiga

# weight_reduction_matrix = qr_alter(torch.from_numpy(weight_reduction_matrix)).numpy()

# # re_test_forward_feature = test_forward_feature @ weight_reduction_matrix.T @ weight_reduction_matrix

# re_test_forward_feature = test_forward_feature @ pca_reduction_matrix.T @ pca_reduction_matrix
# print('re_test_forward_feature: ', re_test_forward_feature.shape)

# re_test_forward_feature = low_test_forward_feature @ weight_reduction_matrix @ weight_reduction_matrix.T

# org = np.linalg.norm(low_test_forward_feature, ord=2, axis=1)
# error = np.linalg.norm(re_test_forward_feature - low_test_forward_feature, ord=2, axis=1)/org

# org = np.linalg.norm(test_forward_feature, ord=2, axis=1)
# error = np.linalg.norm(test_forward_feature - re_test_forward_feature, ord=2, axis=1)/org
# print(error.shape, np.mean(error), np.var(error))

def reconstruction_error(pca_reduction_matrix, weight_reduction_matrix, test_forward_feature, num_classes, save_path, save_name):
    x = np.arange(1, num_classes+1, 1)

    fig = plt.figure()
    ax1 = plt.subplot(111)
    ax1.set_xlabel('dimension of subspace')
    ax1.set_ylabel('reconstruction error')

    # y1 = []
    # y2 = []
    # org = np.linalg.norm(test_forward_feature, ord=2, axis=1)
    # for i in range(1, num_classes+1):
    #     re_test_forward_feature_1 = test_forward_feature @ pca_reduction_matrix[0:i].T @ pca_reduction_matrix[0:i]
    #     re_test_forward_feature_2 = test_forward_feature @ weight_reduction_matrix[0:i].T @ weight_reduction_matrix[0:i]
    #     error_1 = np.linalg.norm(test_forward_feature - re_test_forward_feature_1, ord=2, axis=1)/org
    #     error_2 = np.linalg.norm(test_forward_feature - re_test_forward_feature_2, ord=2, axis=1)/org
    #     y1.append(np.mean(error_1))
    #     y2.append(np.mean(error_2))
    # y1 = np.array(y1)
    # y2 = np.array(y2)
    # np.save('y1.npy', y1)
    # np.save('y2.npy', y2)
    # print(y1)
    # print(y2)
    y1 = np.load('y1.npy')
    y2 = np.load('y2.npy')

    current_palette = sns.color_palette()

    # ax1.plot(x, y1, linestyle='-', color='#8ECFC9', marker='+', label='PCA subspace') 
    # ax1.plot(x, y2, linestyle='-', color='#FFBE7A', marker='+', label = 'Weight subspace')

    ax1.plot(x, y1, linestyle='-', marker='^', color=current_palette[3], markersize=10, label='PCA subspace') # 
    ax1.plot(x, y2, linestyle='-', marker='X', color=current_palette[2], markersize=10, label = 'Weight subspace')

    # ax1.fill_between(x, ratio, color='#8ECFC9', alpha=0.3)  # 在折线图下方填充浅蓝色
    ax1.legend(loc='lower left')
    plt.tight_layout()
    plt.savefig(save_path + save_name + '.png', dpi=800)
    plt.savefig(save_path + save_name + '.pdf', format='pdf', bbox_inches='tight')
    return

reconstruction_error(pca_reduction_matrix, weight_reduction_matrix, test_forward_feature, num_classes, save_path, args.dataset + '_reconstruction_error')
print(fsdfsd)

############################################################################
args.dataset = 'cifar10'
num_classes = 100
pca = sklearn.decomposition.PCA(n_components=num_classes, copy=True, whiten=False)   # 10 dimension occupy 95.5% components
pca.fit(test_forward_feature)
cifar10_ratio = pca.explained_variance_ratio_
save_name = args.dataset + '_test'
for i in range(1, num_classes):
    cifar10_ratio[i] = cifar10_ratio[i] + cifar10_ratio[i-1]
cifar10_ratio = np.insert(cifar10_ratio, 0, 0)


args.dataset = 'cifar100'
num_classes = 100
save_name = args.dataset + '_test'
check = ''
test_forward_feature, test_label, test_feature_dataloader = obtain_feature_loader(net, test_loader, save_path, save_name, args, check)
save_name = args.dataset + '_svhn'
svhn_forward_feature, svhn_label, svhn_feature_dataloader = obtain_feature_loader(net, svhn_loader, save_path, save_name, args, check)

pca = sklearn.decomposition.PCA(n_components=num_classes, copy=True, whiten=False)   # 10 dimension occupy 95.5% components
pca.fit(test_forward_feature)
cifar100_ratio = pca.explained_variance_ratio_
save_name = args.dataset + '_test'
for i in range(1, num_classes):
    cifar100_ratio[i] = cifar100_ratio[i] + cifar100_ratio[i-1]
cifar100_ratio = np.insert(cifar100_ratio, 0, 0)
############################################################################
def principle_component(cifar10_ratio, cifar100_ratio, save_path, save_name):
    x = np.arange(0, 100+1, 1)

    fig = plt.figure()
    ax1 = plt.subplot(111)
    ax1.set_xlabel('number of components')
    ax1.set_ylabel('explained variance ratio')

    ax1.set_xscale('log')
    
    current_palette = sns.color_palette()
    
    markevery = [0,1,3,5,9,31,99]
    ax1.plot(x[1:], cifar10_ratio[1:], linestyle='-', color=current_palette[4], marker='o',  markersize=10, markevery=markevery, label='CIFAR10') # 
    ax1.plot(x[1:], cifar100_ratio[1:], linestyle='-', color=current_palette[5], marker='s',  markersize=10, markevery=markevery, label = 'CIFAR100')
    # ax1.fill_between(x, ratio, color='#8ECFC9', alpha=0.3)  # 在折线图下方填充浅蓝色
    ax1.legend(loc='lower right')
    plt.tight_layout()
    plt.savefig(save_path + save_name + '.png', dpi=800)
    plt.savefig(save_path + save_name + '.pdf', format='pdf', bbox_inches='tight')
    return

def principle_component_2(ratio, num_classes, save_path, save_name):
    x = np.arange(0, num_classes+1, 1)

    fig = plt.figure()
    ax1 = plt.subplot(111)
    ax1.set_xlabel('number of components')
    ax1.set_ylabel('explained variance ratio')

    # ax1.set_xscale('log')
    # ax1.set_ylim(0, 2)
    ax1.plot(x, ratio, linestyle='-', color='#8ECFC9', marker='+', label='CIFAR10' if num_classes==10 else 'CIFAR100') # 
    # ax1.fill_between(x, ratio, color='#8ECFC9', alpha=0.3)  # 在折线图下方填充浅蓝色
    ax1.legend(loc='lower right')
    plt.tight_layout()
    plt.savefig(save_path + save_name + '.png', dpi=800)
    plt.savefig(save_path + save_name + '.pdf', format='pdf', bbox_inches='tight')
    return

save_name = 'test'
principle_component(cifar10_ratio, cifar100_ratio, save_path, save_name+'_ratio')
# principle_component_2(cifar100_ratio, num_classes, save_path, args.dataset + '_' + save_name+'_ratio')
###########################################################################
print(fsdfs)



# indices = [[] for _ in range(num_classes)]
# # 遍历训练集
# for i in range(len(test_data)):
#     img, label = test_data[i]
#     indices[label].append(i)
#     # print(indices[label])
# indices = np.array(indices)   
# print('indices: ', indices.shape)
# np.save(save_path + args.dataset + '_label_indices.npy', indices)

# indices = np.load(save_path + args.dataset + '_label_indices.npy', allow_pickle=True)
# class1 = 0
# class2 = 1

# set_class1 = torch.utils.data.Subset(test_data, indices[class1])
# loader_class1 = torch.utils.data.DataLoader(set_class1, batch_size=args.batch_size, shuffle=False, num_workers=args.threads)

# set_class2 = torch.utils.data.Subset(test_data, indices[class2])
# loader_class2 = torch.utils.data.DataLoader(set_class2, batch_size=args.batch_size, shuffle=False, num_workers=args.threads)


def scatter_plot(x, y, save_path, save_name):
    plt.clf()
    plt.scatter(x[:,0], x[:,1], c='#82B0D2', alpha=1, marker='.', label='Class-1')
    plt.scatter(y[:,0], y[:,1], c='#FFBE7A', alpha=1, marker='.', label='Class-2')
    # plt.scatter(z[:,0], z[:,1], c='#FA7F6F', alpha=1, marker='.', label='Outlier')
    plt.legend()
    plt.tight_layout()
    plt.savefig(save_path + save_name + '.png', dpi=800)
    return

def scatter_plot_single(x, save_name):
    plt.clf()
    plt.scatter(x[:,0], x[:,1], c='#82B0D2', alpha=1, marker='.')
    # plt.legend()
    plt.tight_layout()
    plt.savefig(fig_save_dir+save_name+'.png', dpi=800)
    return


print(net.fc.weight.data.shape)
print(fdsfs)
w1 = net.fc.weight
# x = train_forward_feature @ NS
# y = test_forward_feature @ NS
# z = ood_forward_feature @ NS



scatter_plot(x, y, save_path, save_name)
print('finish plot')
# print(fdsf)