#!/bin/bash
# bash ImageNet-experiment/imagenet_1k_finetune_oe.sh 

CUDA_VISIBLE_DEVICES=2 python ImageNet-experiment/imagenet_1k_finetune_oe.py imagenet-1k --model resnet50 --epochs 500 --momentum 0.9 --learning_rate 0.0001 --decay 0.0001 --batch_size 64 --oe_batch_size 64 --score_type msp

CUDA_VISIBLE_DEVICES=3 python ImageNet-experiment/imagenet_1k_finetune_oe.py imagenet-1k --model resnet50 --epochs 500 --momentum 0.9 --learning_rate 0.0001 --decay 0.0001 --batch_size 64 --oe_batch_size 64 --score_type msp







