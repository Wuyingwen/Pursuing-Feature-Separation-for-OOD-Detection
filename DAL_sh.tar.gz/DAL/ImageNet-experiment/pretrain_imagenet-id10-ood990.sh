#!/bin/bash
# bash ImageNet-experiment/pretrain_imagenet-id10-ood990.sh 

# CUDA_VISIBLE_DEVICES=1 python ImageNet-experiment/pretrain_imagenet-id10-ood990.py tiny-imagenet --model resnet50 --epochs 100 --momentum 0.9 --learning_rate 0.1 --batch_size 256

CUDA_VISIBLE_DEVICES=1 python ImageNet-experiment/pretrain_imagenet-id10-ood990.py tiny-imagenet --model densenet --epochs 100 --momentum 0.9 --learning_rate 0.1 --batch_size 256
