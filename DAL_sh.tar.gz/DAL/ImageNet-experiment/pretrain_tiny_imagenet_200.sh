#!/bin/bash
# bash ImageNet-experiment/pretrain_tiny_imagenet_200.sh 
# CUDA_VISIBLE_DEVICES=1 python ImageNet-experiment/pretrain_tiny_imagenet_200.py tiny-imagenet --epochs 100 --momentum 0.9 --learning_rate 0.1 --batch_size 256
# CUDA_VISIBLE_DEVICES=1 python ImageNet-experiment/pretrain_tiny_imagenet_200.py tiny-imagenet --epochs 200 --momentum 0.9 --learning_rate 0.1 --batch_size 256

CUDA_VISIBLE_DEVICES=1 python ImageNet-experiment/pretrain_tiny_imagenet_200.py tiny-imagenet --model resnet50 --epochs 100 --momentum 0.9 --learning_rate 0.1 --batch_size 256

CUDA_VISIBLE_DEVICES=1 python ImageNet-experiment/pretrain_tiny_imagenet_200.py tiny-imagenet --model densenet --epochs 100 --momentum 0.9 --learning_rate 0.1 --batch_size 256

CUDA_VISIBLE_DEVICES=1 python ImageNet-experiment/pretrain_tiny_imagenet_200.py tiny-imagenet --model resnet18 --epochs 100 --momentum 0.9 --learning_rate 0.1 --batch_size 256
