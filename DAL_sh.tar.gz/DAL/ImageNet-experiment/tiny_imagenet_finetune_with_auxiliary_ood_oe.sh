#!/bin/bash
# bash ImageNet-experiment/tiny_imagenet_finetune_with_auxiliary_ood_oe.sh 

CUDA_VISIBLE_DEVICES=7 python ImageNet-experiment/tiny_imagenet_finetune_with_auxiliary_ood_oe.py tiny-imagenet --model densenet --epochs 100 --momentum 0.9 --learning_rate 0.01 --decay 0.0001 --batch_size 64 --oe_batch_size 64 --score_type msp

# CUDA_VISIBLE_DEVICES=1 python ImageNet-experiment/tiny_imagenet_finetune_with_auxiliary_ood_oe.py tiny-imagenet --model resnet18 --epochs 100 --momentum 0.9 --learning_rate 0.01 --decay 0.0001 --batch_size 64 --oe_batch_size 64


