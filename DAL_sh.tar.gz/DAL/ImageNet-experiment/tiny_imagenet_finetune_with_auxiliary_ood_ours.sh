#!/bin/bash
# bash ImageNet-experiment/tiny_imagenet_finetune_with_auxiliary_ood_ours.sh 

CUDA_VISIBLE_DEVICES=4 python ImageNet-experiment/tiny_imagenet_finetune_with_auxiliary_ood_ours.py tiny-imagenet --model densenet --epochs 100 --momentum 0.9 --learning_rate 0.01 --decay 0.0001 --batch_size 64 --oe_batch_size 64 --stage2_start 0 --alpha 0.1 --beta_ours 0.1 --score_type msp

CUDA_VISIBLE_DEVICES=4 python ImageNet-experiment/tiny_imagenet_finetune_with_auxiliary_ood_ours.py tiny-imagenet --model densenet --epochs 100 --momentum 0.9 --learning_rate 0.01 --decay 0.0001 --batch_size 64 --oe_batch_size 64 --stage2_start 0 --alpha 1 --beta_ours 1 --score_type msp

CUDA_VISIBLE_DEVICES=4 python ImageNet-experiment/tiny_imagenet_finetune_with_auxiliary_ood_ours.py tiny-imagenet --model densenet --epochs 100 --momentum 0.9 --learning_rate 0.01 --decay 0.0001 --batch_size 64 --oe_batch_size 64 --stage2_start 20 --alpha 1 --beta_ours 1 --score_type msp

CUDA_VISIBLE_DEVICES=4 python ImageNet-experiment/tiny_imagenet_finetune_with_auxiliary_ood_ours.py tiny-imagenet --model densenet --epochs 100 --momentum 0.9 --learning_rate 0.01 --decay 0.0001 --batch_size 64 --oe_batch_size 64 --stage2_start 50 --alpha 1 --beta_ours 1 --score_type msp

CUDA_VISIBLE_DEVICES=4 python ImageNet-experiment/tiny_imagenet_finetune_with_auxiliary_ood_ours.py tiny-imagenet --model densenet --epochs 100 --momentum 0.9 --learning_rate 0.01 --decay 0.0001 --batch_size 64 --oe_batch_size 64 --stage2_start 50 --alpha 0.1 --beta_ours 0.1 --score_type msp

# CUDA_VISIBLE_DEVICES=5 python ImageNet-experiment/tiny_imagenet_finetune_with_auxiliary_ood_ours.py tiny-imagenet --model resnet18 --epochs 100 --momentum 0.9 --learning_rate 0.01 --decay 0.0001 --batch_size 64 --oe_batch_size 64 --stage2_start 0 --alpha 0.1 --beta_ours 0.1


