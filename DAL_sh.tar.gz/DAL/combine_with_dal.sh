#!/bin/bash
# CUDA_VISIBLE_DEVICES=1 python combine_with_dal.py cifar10 --score_type msp
# CUDA_VISIBLE_DEVICES=1 python combine_with_dal.py cifar100 --score_type msp

CUDA_VISIBLE_DEVICES=1 python combine_with_dal.py cifar10 --score_type msp --alpha 0.1 --beta_ours 0.1 --stage2_start 10 --epochs 50


# CUDA_VISIBLE_DEVICES=2 python combine_with_dal.py cifar10 --score_type msp --alpha 0.1 --beta_ours 0.1 --stage2_start 0 --epochs 50 --version v2

# CUDA_VISIBLE_DEVICES=3 python combine_with_dal.py cifar10 --score_type msp --alpha 0.1 --beta_ours 0.1 --stage2_start 0 --epochs 50 --version pure_dal