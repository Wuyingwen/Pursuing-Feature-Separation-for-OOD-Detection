#!/bin/bash
# CUDA_VISIBLE_DEVICES=1 python combine_with_energy_oe.py cifar10 --score_type energy --epochs 70
# CUDA_VISIBLE_DEVICES=1 python combine_with_energy_oe.py cifar100 --score_type energy --epochs 70
CUDA_VISIBLE_DEVICES=1 python combine_with_energy_oe.py cifar10 --score_type energy --epochs 70 --alpha 0.1 --beta 0.1

