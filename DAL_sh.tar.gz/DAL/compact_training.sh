#!/bin/bash
CUDA_VISIBLE_DEVICES=2 python compact_training.py cifar10
CUDA_VISIBLE_DEVICES=2 python compact_training.py cifar100