#!/bin/bash
CUDA_VISIBLE_DEVICES=5 python compact_training_with_adaptive_weight.py cifar10 --adaptive_strategy linear --max_alpha 1.0 --min_alpha 0.01 --max_beta 1.0 --min_beta 0.01
CUDA_VISIBLE_DEVICES=5 python compact_training_with_adaptive_weight.py cifar100 --adaptive_strategy linear --max_alpha 1.0 --min_alpha 0.01 --max_beta 1.0 --min_beta 0.01

CUDA_VISIBLE_DEVICES=5 python compact_training_with_adaptive_weight.py cifar10 --adaptive_strategy cosine --max_alpha 1.0 --min_alpha 0.01 --max_beta 1.0 --min_beta 0.01
CUDA_VISIBLE_DEVICES=5 python compact_training_with_adaptive_weight.py cifar100 --adaptive_strategy cosine --max_alpha 1.0 --min_alpha 0.01 --max_beta 1.0 --min_beta 0.01