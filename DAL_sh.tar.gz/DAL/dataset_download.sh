export http_proxy='http://10.253.34.172:6666'
export https_proxy='http://10.253.34.172:6666'
export HF_ENDPOINT=https://hf-mirror.com

cd /home/hadoop-contentunderstanding/dolphinfs_hdd_hadoop-contentunderstanding/wuyingwen02/DAL


# https://huggingface.co/datasets/LanguageBind/Video-LLaVA/tree/main
# huggingface-cli download --token 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 --repo-type dataset --resume-download ILSVRC/imagenet-1k --cache-dir ../cache_data --local-dir data/imagenet/ --local-dir-use-symlinks False #--force-download

huggingface-cli download --token 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 --repo-type dataset --resume-download zeyuanyin/imagenet-21k-p --cache-dir ../cache_data --local-dir data/imagenet-21k-p/ --local-dir-use-symlinks False #--force-download
