#!/bin/bash
for alpha in {0.1,0.5,1,2}
do
    for beta in {0.1,0.5,1,2}
    do 
    python influence_of_loss_weight.py cifar10 --alpha $alpha --beta $beta
    done
done

for alpha in {0.1,0.5,1,2}
do
    for beta in {0.1,0.5,1,2}
    do 
    python influence_of_loss_weight.py cifar100 --alpha $alpha --beta $beta
    done
done
