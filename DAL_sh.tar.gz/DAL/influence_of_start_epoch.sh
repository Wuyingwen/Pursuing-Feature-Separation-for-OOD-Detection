#!/bin/bash
CUDA_VISIBLE_DEVICES=4 python influence_of_start_epoch.py cifar10 --stage2_start 10 --alpha 0.1 --beta 0.1
CUDA_VISIBLE_DEVICES=4 python influence_of_start_epoch.py cifar100 --stage2_start 10 --alpha 0.1 --beta 0.1

CUDA_VISIBLE_DEVICES=4 python influence_of_start_epoch.py cifar10 --stage2_start 20 --alpha 0.1 --beta 0.1
CUDA_VISIBLE_DEVICES=4 python influence_of_start_epoch.py cifar100 --stage2_start 20 --alpha 0.1 --beta 0.1

CUDA_VISIBLE_DEVICES=4 python influence_of_start_epoch.py cifar10 --stage2_start 25 --alpha 0.1 --beta 0.1
CUDA_VISIBLE_DEVICES=4 python influence_of_start_epoch.py cifar100 --stage2_start 25 --alpha 0.1 --beta 0.1

CUDA_VISIBLE_DEVICES=4 python influence_of_start_epoch.py cifar10 --stage2_start 30 --alpha 0.1 --beta 0.1
CUDA_VISIBLE_DEVICES=4 python influence_of_start_epoch.py cifar100 --stage2_start 30 --alpha 0.1 --beta 0.1

CUDA_VISIBLE_DEVICES=4 python influence_of_start_epoch.py cifar10 --stage2_start 40 --alpha 0.1 --beta 0.1
CUDA_VISIBLE_DEVICES=4 python influence_of_start_epoch.py cifar100 --stage2_start 40 --alpha 0.1 --beta 0.1

CUDA_VISIBLE_DEVICES=4 python influence_of_start_epoch.py cifar10 --stage2_start 50 --alpha 0.1 --beta 0.1
CUDA_VISIBLE_DEVICES=4 python influence_of_start_epoch.py cifar100 --stage2_start 50 --alpha 0.1 --beta 0.1