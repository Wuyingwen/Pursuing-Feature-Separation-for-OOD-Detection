# python main_sam.py cifar10 --gamma=10 --beta=.01  --rho=10  --iter=10 --learning_rate=0.07 --strength=1 --sam_type lce
# python main_sam.py cifar100  --gamma=10 --beta=.005  --rho=10  --iter=10 --learning_rate=0.07 --strength=1 --sam_type lce

# python main_sam.py cifar10 --gamma=10 --beta=.01  --rho=10  --iter=10 --learning_rate=0.07 --strength=1 --sam_type loe
# python main_sam.py cifar100  --gamma=10 --beta=.005  --rho=10  --iter=10 --learning_rate=0.07 --strength=1 --sam_type loe

# python main_sam.py cifar10 --gamma=10 --beta=.01  --rho=10  --iter=10 --learning_rate=0.07 --strength=1 --sam_type lce+loe
# python main_sam.py cifar100  --gamma=10 --beta=.005  --rho=10  --iter=10 --learning_rate=0.07 --strength=1 --sam_type lce+loe


# CUDA_VISIBLE_DEVICES=3 python main_sam.py cifar100  --gamma=10 --beta=.005  --rho=10  --iter=10 --learning_rate=0.07 --strength=1 --oe_batch_size 256
# CUDA_VISIBLE_DEVICES=3 python main_sam.py cifar10 --gamma=10 --beta=.01  --rho=10  --iter=10 --learning_rate=0.07 --strength=1 --oe_batch_size 256

CUDA_VISIBLE_DEVICES=2 python main_sam.py cifar100  --gamma=10 --beta=.005  --rho=10  --iter=10 --learning_rate=0.07 --strength=1 --oe_batch_size 512
CUDA_VISIBLE_DEVICES=2 python main_sam.py cifar10 --gamma=10 --beta=.01  --rho=10  --iter=10 --learning_rate=0.07 --strength=1 --oe_batch_size 512
