# python more_architecture.py cifar10 --model resnet --alpha 0.1 --beta_ours 0.1 --stage2_start 0 --learning_rate 0.03
python more_architecture.py cifar10 --model densenet --alpha 0.1 --beta_ours 0.1 --stage2_start 0 --learning_rate 0.03

# python more_architecture.py cifar100 --model resnet --alpha 0.1 --beta_ours 0.1 --stage2_start 0 --learning_rate 0.03
python more_architecture.py cifar100 --model densenet --alpha 0.1 --beta_ours 0.1 --stage2_start 0 --learning_rate 0.03
