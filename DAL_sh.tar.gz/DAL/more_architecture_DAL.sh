# CUDA_VISIBLE_DEVICES=5 python more_architecture_DAL.py cifar10 --model resnet --learning_rate 0.03 --score_type msp
CUDA_VISIBLE_DEVICES=5 python more_architecture_DAL.py cifar10 --model densenet --learning_rate 0.03 --score_type msp

# CUDA_VISIBLE_DEVICES=5 python more_architecture_DAL.py cifar100 --model resnet --learning_rate 0.03 --score_type msp
CUDA_VISIBLE_DEVICES=5 python more_architecture_DAL.py cifar100 --model densenet --learning_rate 0.03 --score_type msp

