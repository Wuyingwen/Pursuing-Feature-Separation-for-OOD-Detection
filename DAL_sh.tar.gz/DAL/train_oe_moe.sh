

CUDA_VISIBLE_DEVICES=3 python train_oe_moe.py cifar10 --model wideresnet --learning_rate 0.07 --score_type msp
# CUDA_VISIBLE_DEVICES=3 python train_oe_moe.py cifar100 --model wideresnet --learning_rate 0.07 --score_type msp

# CUDA_VISIBLE_DEVICES=0 python train_oe_moe.py cifar100 --model resnet --learning_rate 0.03 --score_type msp
